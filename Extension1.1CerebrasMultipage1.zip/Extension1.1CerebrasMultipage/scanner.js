/* ============================================================================
 * DigitalClerk — scanner.js  (site-agnostic hardened scan)
 * ----------------------------------------------------------------------------
 * WHY THIS VERSION:
 *  A field must NEVER be silently lost on any site. This scanner now:
 *   1) SAFETY NET: unions the recursive DOM walk with a plain
 *      querySelectorAll('input,select,textarea'), so a field the walk misses
 *      (quirky nesting, timing, custom elements) is still caught.
 *   2) PER-FIELD try/catch: one weird field can never throw and truncate the
 *      whole scan.
 *   3) DROP LOGGING: every element that is intentionally skipped is logged with
 *      a reason (visible in DevTools), so drops are auditable in QA instead of
 *      being invisible.
 *
 *  NOTE: whether a <select> sitting on its "--Select--" placeholder is treated
 *  as fillable is decided in content.js (hasValue), NOT here — the scanner
 *  reports the field either way.
 *
 * ── CONTEXT UPGRADE (this revision) ─────────────────────────────────────────
 *  The mapper was receiving label:"" and previousHeading:"" for nearly every
 *  field on real gov forms, so the LLM was mapping from the field id ALONE
 *  (guessing at ids like typeResult / classGradeLookupId / modeLookupId).
 *  Root cause: the old getLabelText only understood <label for> and wrapping
 *  <label>; gov forms put the caption in a plain <div>/<span>/<td>. And
 *  getPreviousHeading only accepted <h1>-<h6>, while these forms use styled
 *  divs. Fixes:
 *    - getLabelText   -> adds aria-labelledby + DOM-proximity fallbacks
 *                        (getNearbyCaption): previous siblings, table cell to
 *                        the left, single-control wrapper text.
 *    - getPreviousHeading -> also accepts heading-LIKE nodes (legend/th/caption
 *                        or class~=heading|title|section).
 *    - getHintText (NEW) -> captures the helper line under an input, e.g.
 *                        "Please enter your name as per 10th or equivalent
 *                        examination." That sentence states WHICH DOCUMENT the
 *                        value must come from and is decisive for mapping; it
 *                        was previously captured by nothing at all.
 *  All are best-effort and individually guarded — they can only ADD context,
 *  never drop a field.
 * ==========================================================================*/

window.DigitalClerkScanner = {
    scanFormFields: function () {
        console.log("DigitalClerk: Scanning form fields...");
        const fields = [];
        const dropped = [];   // {reason, id/name/tag} for auditability

        // ---- Collect candidate elements from BOTH sources, then de-dupe ----
        // Source A: recursive walk (pierces shadow DOM).
        const walked = this.getAllElements(document.body);
        // Source B: plain query (safety net for anything the walk missed).
        let queried = [];
        try {
            queried = Array.from(document.querySelectorAll('input, select, textarea'));
        } catch (e) {
            queried = [];
        }

        // Union by element identity (a Set de-dupes the same node).
        const candidateSet = new Set();
        for (const el of walked) candidateSet.add(el);
        for (const el of queried) candidateSet.add(el);
        const candidates = Array.from(candidateSet);

        for (const el of candidates) {
            try {
                const tag = (el.tagName || '').toLowerCase();
                if (tag !== 'input' && tag !== 'select' && tag !== 'textarea') {
                    continue; // not a form control
                }

                const type = (el.type || '').toLowerCase();

                // --- skip rules (each logged with a reason) ---
                if (['hidden', 'submit', 'button', 'reset', 'file', 'image'].includes(type)) {
                    dropped.push({ reason: 'type=' + type, id: el.id || el.name || tag });
                    continue;
                }
                if (el.disabled) {
                    dropped.push({ reason: 'disabled', id: el.id || el.name || tag });
                    continue;
                }
                // NOTE: readOnly is only meaningful for text-like inputs; a <select>
                // has readOnly === undefined, so this never wrongly drops selects.
                if (el.readOnly === true) {
                    dropped.push({ reason: 'readOnly', id: el.id || el.name || tag });
                    continue;
                }
                // Use computed style (not just inline) so class-based hiding is caught,
                // but be conservative: only drop if clearly not rendered.
                let cs = null;
                try { cs = window.getComputedStyle(el); } catch (e) { cs = null; }
                if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) {
                    dropped.push({ reason: 'css-hidden', id: el.id || el.name || tag });
                    continue;
                }
                // Fallback inline check (in case computed style unavailable).
                if (el.style && (el.style.display === 'none' || el.style.visibility === 'hidden')) {
                    dropped.push({ reason: 'inline-hidden', id: el.id || el.name || tag });
                    continue;
                }

                // --- build the field record (guarded) ---
                const fieldData = {
                    id: el.id || el.name || this.generateFallbackId(el),
                    name: el.name || '',
                    type: (el.type || el.tagName).toLowerCase(),
                    tagName: el.tagName.toLowerCase(),
                    placeholder: el.placeholder || '',
                    label: this.getLabelText(el),
                    ariaLabel: el.getAttribute ? (el.getAttribute('aria-label') || '') : '',
                    maxLength: (el.maxLength > 0) ? el.maxLength : null,
                    pattern: el.pattern || null,
                    required: el.required || (el.getAttribute && el.getAttribute('aria-required') === 'true'),
                    previousHeading: this.getPreviousHeading(el),
                    // NEW: instruction/helper text tied to this field. Often names the
                    // source document ("as per 10th marksheet") — decisive for mapping.
                    hint: this.getHintText(el),
                    signature: this.getFieldSignature(el)
                };

                if (fieldData.tagName === 'select') {
                    fieldData.options = Array.from(el.options || []).map(opt => ({
                        value: opt.value,
                        text: opt.text
                    }));
                }

                if (fieldData.type === 'radio' || fieldData.type === 'checkbox') {
                    fieldData.value = el.value;
                }

                fields.push(fieldData);
            } catch (err) {
                // One bad field must never kill the scan.
                dropped.push({ reason: 'build-threw: ' + (err && err.message), id: (el && (el.id || el.name)) || '?' });
            }
        }

        // De-dupe fields by id (walk + query can produce the same element via
        // different paths; the Set above handles element identity, but fallback ids
        // could still collide — keep the first occurrence).
        const seen = new Set();
        const deduped = [];
        for (const f of fields) {
            if (seen.has(f.id)) continue;
            seen.add(f.id);
            deduped.push(f);
        }

        console.log(`DigitalClerk: Found ${deduped.length} valid fields.` +
            (dropped.length ? ` (skipped ${dropped.length})` : ''));
        if (dropped.length) {
            // Auditable in QA: see exactly what was skipped and why.
            console.debug('DigitalClerk: skipped elements ->', dropped);
        }

        // QA VISIBILITY: how many fields actually carry usable context? If this
        // shows 0/20 labelled on a form that clearly has captions, the fallbacks
        // below need another pattern for that site.
        try {
            const labelled = deduped.filter(f => f.label).length;
            const hinted = deduped.filter(f => f.hint).length;
            console.debug(`DigitalClerk: context -> ${labelled}/${deduped.length} labelled, ${hinted} with hints.`);
        } catch (e) { /* logging only */ }

        return deduped;
    },

    getAllElements: function (root) {
        const elements = [];
        const traverse = (node) => {
            if (!node) return;
            if (node.nodeType === Node.ELEMENT_NODE) {
                elements.push(node);
                if (node.shadowRoot) {
                    traverse(node.shadowRoot);
                }
            }
            const kids = node.childNodes || [];
            for (let child of kids) {
                traverse(child);
            }
        };
        traverse(root);
        return elements;
    },

    // ── small shared helpers ────────────────────────────────────────────────
    _clean: function (s) {
        return (s || '').replace(/\s+/g, ' ').trim();
    },

    _hasControl: function (el) {
        try { return !!(el && el.querySelector && el.querySelector('input, select, textarea')); }
        catch (e) { return false; }
    },

    /**
     * The caption for a field.
     * Order: <label for> -> wrapping <label> -> aria-labelledby -> DOM proximity.
     * The last one is what makes this work on real gov forms, which usually put
     * the caption in a plain <div>/<span>/<td> and never use <label> at all.
     */
    getLabelText: function (field) {
        let labelText = '';
        try {
            // (1) <label for="id">
            if (field.id) {
                const safe = (window.CSS && CSS.escape) ? CSS.escape(field.id) : field.id;
                const label = document.querySelector(`label[for="${safe}"]`);
                if (label) labelText += label.innerText + " ";
            }

            // (2) wrapping <label>
            const parentLabel = field.closest ? field.closest('label') : null;
            if (parentLabel && parentLabel !== field) {
                const clone = parentLabel.cloneNode(true);
                const inputInside = clone.querySelector('input, select, textarea');
                if (inputInside) inputInside.remove();
                labelText += clone.innerText.trim() + " ";
            }

            // (3) aria-labelledby -> the element(s) it points at
            if (!labelText.trim() && field.getAttribute) {
                const ids = (field.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
                for (const id of ids) {
                    const el = document.getElementById(id);
                    if (el) labelText += this._clean(el.innerText) + " ";
                }
            }

            // (4) FALLBACK — the big one (see header note).
            if (!labelText.trim()) {
                labelText = this.getNearbyCaption(field) || '';
            }
        } catch (e) { /* label is best-effort */ }
        return this._clean(labelText);
    },

    /**
     * Find a caption in the field's immediate neighbourhood.
     * Deliberately conservative: short strings only, and never a node that itself
     * contains a form control (that would grab a neighbouring field's caption).
     */
    getNearbyCaption: function (field) {
        const clean = this._clean.bind(this);
        const usable = (s) => s && s.length > 1 && s.length <= 120;

        try {
            // (a) Previous element siblings — of the field, then of its wrappers.
            //     This catches the common "caption div sits above the input" layout.
            let node = field;
            for (let up = 0; up < 4 && node; up++) {
                let prev = node.previousElementSibling;
                let hops = 0;
                while (prev && hops < 3) {
                    const t = clean(prev.innerText);
                    if (usable(t) && !this._hasControl(prev)) {
                        return t;
                    }
                    prev = prev.previousElementSibling;
                    hops++;
                }
                node = node.parentElement;
            }

            // (b) Table layouts: the caption is often the cell to the left.
            const td = field.closest ? field.closest('td') : null;
            if (td) {
                const leftCell = td.previousElementSibling;
                if (leftCell && !this._hasControl(leftCell)) {
                    const t = clean(leftCell.innerText);
                    if (usable(t)) return t;
                }
            }

            // (c) Wrapper text minus the control itself (bootstrap form-group pattern).
            //     Only when the wrapper holds exactly ONE control, so we can't steal
            //     a neighbour's caption.
            const wrapper = field.closest
                ? field.closest('.form-group, .form-item, .field, .col, .col-md-4, .col-sm-6, div')
                : null;
            if (wrapper && wrapper !== field) {
                let controls = [];
                try { controls = wrapper.querySelectorAll('input, select, textarea'); } catch (e) { controls = []; }
                if (controls.length === 1) {
                    const cloneW = wrapper.cloneNode(true);
                    cloneW.querySelectorAll('input, select, textarea, option').forEach(n => n.remove());
                    const t = clean(cloneW.innerText);
                    if (usable(t)) return t;
                }
            }
        } catch (e) { /* best-effort */ }
        return '';
    },

    /**
     * Section heading above the field ("Personal Details", "Qualification Details").
     * Old version required <h1>-<h6>; gov forms use styled divs, so it returned "".
     * Now also accepts heading-LIKE nodes.
     */
    getPreviousHeading: function (field) {
        const clean = this._clean.bind(this);
        try {
            let current = field;
            let guard = 0;
            while (current && guard++ < 300) {
                const prev = current.previousElementSibling;
                if (prev) {
                    // Real heading tags.
                    if (/^H[1-6]$/i.test(prev.tagName)) {
                        const t = clean(prev.innerText);
                        if (t) return t;
                    }
                    // Heading-LIKE: legend/th/caption, or a class that smells like a heading.
                    const cls = (prev.className || '').toString().toLowerCase();
                    const looksHeading =
                        /^(LEGEND|TH|CAPTION)$/i.test(prev.tagName) ||
                        /heading|title|section|panel-head|card-head/.test(cls);
                    if (looksHeading && !this._hasControl(prev)) {
                        const t = clean(prev.innerText);
                        if (t && t.length <= 120) return t;
                    }
                    current = prev;
                } else {
                    current = current.parentElement;
                }
            }
        } catch (e) { /* best-effort */ }
        return '';
    },

    /**
     * NEW: helper/instruction text attached to a field, e.g.
     *   "Please enter your name as per 10th or equivalent examination."
     * These sentences frequently name the SOURCE DOCUMENT a value must come from,
     * which the mapper needs in order to choose between (say) an Aadhaar name and
     * a marksheet name. Nothing captured this before.
     */
    getHintText: function (field) {
        const clean = this._clean.bind(this);
        try {
            if (field.getAttribute) {
                // (1) aria-describedby is the standards-compliant home for hints.
                const ids = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
                for (const id of ids) {
                    const el = document.getElementById(id);
                    const t = clean(el && el.innerText);
                    if (t) return t.slice(0, 160);
                }
                // (2) title attribute.
                const title = clean(field.getAttribute('title'));
                if (title) return title.slice(0, 160);
            }

            // (3) Sibling hint nodes right AFTER the input (<small>, .help-block,
            //     .text-muted, .hint, .note ...). Walk up a couple of wrappers too.
            let node = field;
            for (let up = 0; up < 3 && node; up++) {
                let next = node.nextElementSibling;
                let hops = 0;
                while (next && hops < 3) {
                    const cls = (next.className || '').toString().toLowerCase();
                    const isHintTag = /^(SMALL|P|SPAN|DIV|EM|I)$/i.test(next.tagName);
                    const isHint = isHintTag &&
                        (next.tagName === 'SMALL' ||
                         /hint|help|note|instruction|small|text-muted|info/.test(cls));
                    if (isHint && !this._hasControl(next)) {
                        const t = clean(next.innerText);
                        if (t && t.length <= 160) return t;
                    }
                    next = next.nextElementSibling;
                    hops++;
                }
                node = node.parentElement;
            }
        } catch (e) { /* best-effort */ }
        return '';
    },

    generateFallbackId: function (el) {
        if (!el.dataset) return 'dc_field_' + Math.random().toString(36).substring(2, 9);
        if (!el.dataset.dcId) {
            el.dataset.dcId = 'dc_field_' + Math.random().toString(36).substring(2, 9);
        }
        return el.dataset.dcId;
    },

    // "State fingerprint" of a field as it looks RIGHT NOW. The fill loop compares
    // this between passes: if it changes (e.g. a dependent dropdown goes from 0 to
    // 36 options after its parent is set), the loop re-sends the field.
    getFieldSignature: function (input) {
        try {
            const tag = input.tagName.toLowerCase();
            const optionCount = input.options ? input.options.length : 0;
            const disabled = input.disabled ? 1 : 0;
            const visible = (input.offsetWidth > 0 || input.offsetHeight > 0) ? 1 : 0;

            let optHash = 0;
            if (input.options) {
                const joined = Array.from(input.options).map(o => o.text).join('|');
                for (let i = 0; i < joined.length; i++) {
                    optHash = (optHash * 31 + joined.charCodeAt(i)) | 0;
                }
            }
            return `${tag}:${optionCount}:${disabled}:${visible}:${optHash}`;
        } catch (e) {
            return 'sig-err';
        }
    }
};

// Listen for scan requests from the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'scanForm') {
        const fields = window.DigitalClerkScanner.scanFormFields();
        sendResponse({ success: true, fields: fields });
    }
    return true;
});