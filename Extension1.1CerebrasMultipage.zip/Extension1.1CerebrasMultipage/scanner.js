/* ============================================================================
 * DigitalClerk — scanner.js  (site-agnostic hardened scan)
 * ----------------------------------------------------------------------------
 * WHY THIS VERSION:
 *  A field must NEVER be silently lost on any site. This scanner now:
 *   1) SAFETY NET: unions the recursive DOM walk with a plain
 *      querySelectorAll('input,select,textarea'), so a field the walk misses
 *      (quirky nesting, timing, custom elements) is still caught.
 *   2) PER-FIELD try/catch: one weird field can never throw and truncate the
 *      whole scan.
 *   3) DROP LOGGING: every element that is intentionally skipped is logged with
 *      a reason (visible in DevTools), so drops are auditable in QA instead of
 *      being invisible.
 *
 *  NOTE: whether a <select> sitting on its "--Select--" placeholder is treated
 *  as fillable is decided in content.js (hasValue), NOT here — the scanner
 *  reports the field either way.
 * ==========================================================================*/

window.DigitalClerkScanner = {
    scanFormFields: function () {
        console.log("DigitalClerk: Scanning form fields...");
        const fields = [];
        const dropped = [];   // {reason, id/name/tag} for auditability

        // ---- Collect candidate elements from BOTH sources, then de-dupe ----
        // Source A: recursive walk (pierces shadow DOM).
        const walked = this.getAllElements(document.body);
        // Source B: plain query (safety net for anything the walk missed).
        let queried = [];
        try {
            queried = Array.from(document.querySelectorAll('input, select, textarea'));
        } catch (e) {
            queried = [];
        }

        // Union by element identity (a Set de-dupes the same node).
        const candidateSet = new Set();
        for (const el of walked) candidateSet.add(el);
        for (const el of queried) candidateSet.add(el);
        const candidates = Array.from(candidateSet);

        for (const el of candidates) {
            try {
                const tag = (el.tagName || '').toLowerCase();
                if (tag !== 'input' && tag !== 'select' && tag !== 'textarea') {
                    continue; // not a form control
                }

                const type = (el.type || '').toLowerCase();

                // --- skip rules (each logged with a reason) ---
                if (['hidden', 'submit', 'button', 'reset', 'file', 'image'].includes(type)) {
                    dropped.push({ reason: 'type=' + type, id: el.id || el.name || tag });
                    continue;
                }
                if (el.disabled) {
                    dropped.push({ reason: 'disabled', id: el.id || el.name || tag });
                    continue;
                }
                // NOTE: readOnly is only meaningful for text-like inputs; a <select>
                // has readOnly === undefined, so this never wrongly drops selects.
                if (el.readOnly === true) {
                    dropped.push({ reason: 'readOnly', id: el.id || el.name || tag });
                    continue;
                }
                // Use computed style (not just inline) so class-based hiding is caught,
                // but be conservative: only drop if clearly not rendered.
                let cs = null;
                try { cs = window.getComputedStyle(el); } catch (e) { cs = null; }
                if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) {
                    dropped.push({ reason: 'css-hidden', id: el.id || el.name || tag });
                    continue;
                }
                // Fallback inline check (in case computed style unavailable).
                if (el.style && (el.style.display === 'none' || el.style.visibility === 'hidden')) {
                    dropped.push({ reason: 'inline-hidden', id: el.id || el.name || tag });
                    continue;
                }

                // --- build the field record (guarded) ---
                const fieldData = {
                    id: el.id || el.name || this.generateFallbackId(el),
                    name: el.name || '',
                    type: (el.type || el.tagName).toLowerCase(),
                    tagName: el.tagName.toLowerCase(),
                    placeholder: el.placeholder || '',
                    label: this.getLabelText(el),
                    ariaLabel: el.getAttribute ? (el.getAttribute('aria-label') || '') : '',
                    maxLength: (el.maxLength > 0) ? el.maxLength : null,
                    pattern: el.pattern || null,
                    required: el.required || (el.getAttribute && el.getAttribute('aria-required') === 'true'),
                    previousHeading: this.getPreviousHeading(el),
                    signature: this.getFieldSignature(el)
                };

                if (fieldData.tagName === 'select') {
                    fieldData.options = Array.from(el.options || []).map(opt => ({
                        value: opt.value,
                        text: opt.text
                    }));
                }

                if (fieldData.type === 'radio' || fieldData.type === 'checkbox') {
                    fieldData.value = el.value;
                }

                fields.push(fieldData);
            } catch (err) {
                // One bad field must never kill the scan.
                dropped.push({ reason: 'build-threw: ' + (err && err.message), id: (el && (el.id || el.name)) || '?' });
            }
        }

        // De-dupe fields by id (walk + query can produce the same element via
        // different paths; the Set above handles element identity, but fallback ids
        // could still collide — keep the first occurrence).
        const seen = new Set();
        const deduped = [];
        for (const f of fields) {
            if (seen.has(f.id)) continue;
            seen.add(f.id);
            deduped.push(f);
        }

        console.log(`DigitalClerk: Found ${deduped.length} valid fields.` +
            (dropped.length ? ` (skipped ${dropped.length})` : ''));
        if (dropped.length) {
            // Auditable in QA: see exactly what was skipped and why.
            console.debug('DigitalClerk: skipped elements ->', dropped);
        }
        return deduped;
    },

    getAllElements: function (root) {
        const elements = [];
        const traverse = (node) => {
            if (!node) return;
            if (node.nodeType === Node.ELEMENT_NODE) {
                elements.push(node);
                if (node.shadowRoot) {
                    traverse(node.shadowRoot);
                }
            }
            const kids = node.childNodes || [];
            for (let child of kids) {
                traverse(child);
            }
        };
        traverse(root);
        return elements;
    },

    getLabelText: function (field) {
        let labelText = '';
        try {
            if (field.id) {
                const safe = (window.CSS && CSS.escape) ? CSS.escape(field.id) : field.id;
                const label = document.querySelector(`label[for="${safe}"]`);
                if (label) labelText += label.innerText + " ";
            }
            const parentLabel = field.closest ? field.closest('label') : null;
            if (parentLabel && parentLabel !== field) {
                const clone = parentLabel.cloneNode(true);
                const inputInside = clone.querySelector('input, select, textarea');
                if (inputInside) inputInside.remove();
                labelText += clone.innerText.trim() + " ";
            }
        } catch (e) { /* label is best-effort */ }
        return labelText.trim();
    },

    getPreviousHeading: function (field) {
        try {
            let current = field;
            while (current) {
                const prev = current.previousElementSibling;
                if (prev) {
                    if (/^H[1-6]$/i.test(prev.tagName)) {
                        return prev.innerText.trim();
                    }
                    current = prev;
                } else {
                    current = current.parentElement;
                }
            }
        } catch (e) { /* best-effort */ }
        return '';
    },

    generateFallbackId: function (el) {
        if (!el.dataset) return 'dc_field_' + Math.random().toString(36).substring(2, 9);
        if (!el.dataset.dcId) {
            el.dataset.dcId = 'dc_field_' + Math.random().toString(36).substring(2, 9);
        }
        return el.dataset.dcId;
    },

    // "State fingerprint" of a field as it looks RIGHT NOW. The fill loop compares
    // this between passes: if it changes (e.g. a dependent dropdown goes from 0 to
    // 36 options after its parent is set), the loop re-sends the field.
    getFieldSignature: function (input) {
        try {
            const tag = input.tagName.toLowerCase();
            const optionCount = input.options ? input.options.length : 0;
            const disabled = input.disabled ? 1 : 0;
            const visible = (input.offsetWidth > 0 || input.offsetHeight > 0) ? 1 : 0;

            let optHash = 0;
            if (input.options) {
                const joined = Array.from(input.options).map(o => o.text).join('|');
                for (let i = 0; i < joined.length; i++) {
                    optHash = (optHash * 31 + joined.charCodeAt(i)) | 0;
                }
            }
            return `${tag}:${optionCount}:${disabled}:${visible}:${optHash}`;
        } catch (e) {
            return 'sig-err';
        }
    }
};

// Listen for scan requests from the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'scanForm') {
        const fields = window.DigitalClerkScanner.scanFormFields();
        sendResponse({ success: true, fields: fields });
    }
    return true;
});