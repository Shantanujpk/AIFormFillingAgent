// DigitalClerk Extension - Updated Version
class DigitalClerkPopup {
    constructor() {
        /* API Configuration */
        //this.API_URL = 'http://localhost:4000/api/v1';
        this.API_URL = 'https://digital-clerk-b2c-backend-backup.onrender.com/api/v1';
        this.WEBSITE_URL = 'https://expletify.com';

        /* MOCK MODE - Set to false when backend is ready */
        this.MOCK_MODE = false;

        this.user = null;
        this.authToken = null;
        this.uploadedDocuments = [];

        this.init();
    }

    async init() {
        /* Check if user is already logged in */
        await this.checkAuth();
        this.setupEventListeners();
    }

    async checkAuth() {
        try {
            const result = await chrome.storage.local.get(['authToken', 'user']);

            if (result.authToken) {
                this.authToken = result.authToken;
                this.user = result.user;

                console.log(this.user);

                /* Verify token with backend(if not in mock mode) */
                if (!this.MOCK_MODE) {
                    const isValid = await this.verifyToken();
                    if (!isValid) {
                        await this.handleLogout(true); // Silent logout
                        return;
                    }
                }

                /* Check subscription status */
                if (this.user.subscriptionStatus === 'EXPIRED') {
                    this.showMainScreen();
                    this.showExpiredWarning();
                } else {
                    this.showMainScreen();
                }
            } else {
                this.showAuthScreen();
            }
        } catch (error) {
            console.error('Auth check error:', error);
            this.showAuthScreen();
        }

        this.hideLoading();
    }

    async verifyToken() {
        try {
            const response = await fetch(`${this.API_URL}/account/verify-token`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization": `Bearer ${this.authToken}`
                },
                body: JSON.stringify({
                    token: this.authToken
                })
            });
            const data = await response.json();

            if (data.isValid) {
                /* Update user data */
                if (data.user) {
                    this.user = data.user;
                    await chrome.storage.local.set({
                        user: data.user
                    });
                }
                return true;
            }
            return false;
        } catch (error) {
            console.error('Token verification error:', error);
            return false;
        }
    }

    setupEventListeners() {
        /* Auth buttons */
        document.getElementById('loginBtn').addEventListener('click', () => this.handleLogin());

        /* Enter key for login */
        document.getElementById('loginEmail').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') document.getElementById('loginPassword').focus();
        });

        document.getElementById('loginPassword').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleLogin();
        });

        /* Main menu buttons */
        document.getElementById('quickFillBtn').addEventListener('click', () => this.showQuickFillSection());
        document.getElementById('logoutBtn').addEventListener('click', () => this.handleLogout());
        document.getElementById('upgradeLink').addEventListener('click', () => this.openUpgradePage());
        document.getElementById('renewBtn').addEventListener('click', () => this.openRenewPage());

        /* Quick fill section */
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');

        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        uploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        uploadArea.addEventListener('drop', (e) => this.handleDrop(e));

        fileInput.addEventListener('change', (e) => this.handleFileSelect(e));

        document.getElementById('doneBtn').addEventListener('click', () => this.handleDone());
        document.getElementById('backBtn').addEventListener('click', () => this.showMainMenu());

        /* Search Document Types */
        const searchInput = document.getElementById('docSearchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                const cards = document.querySelectorAll('.doc-card');

                cards.forEach(card => {
                    const name = card.querySelector('.doc-name').textContent.toLowerCase();
                    // const value = card.dataset.value.toLowerCase(); // Optional: search by internal value too

                    if (name.includes(searchTerm)) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        }

        // Toggle Manual Data Section
        const toggleBtn = document.getElementById('toggleManualDataBtn');
        const content = document.getElementById('manualDataContent');
        const chevron = toggleBtn.querySelector('.icon-chevron');

        toggleBtn.addEventListener('click', () => {
            if (content.style.display === 'none') {
                content.style.display = 'block';
                content.style.animation = 'slideIn 0.3s ease';
                chevron.textContent = '▲';
            } else {
                content.style.display = 'none';
                chevron.textContent = '▼';
            }
        });

        // Domain & Form Navigation
        document.getElementById('backToDomainsBtn').addEventListener('click', () => this.showDomains());
        document.getElementById('backToFormsBtn').addEventListener('click', () => {
            const domainId = document.getElementById('backToFormsBtn').dataset.domainId;
            // Since we don't store full domain list/forms in memory easily without a fetch, 
            // the simplest is either to go back to domains or store the last domain data.
            // For now, back to domains is safest or requires storing currentDomainForms.
            this.showDomains();
        });
    }

    getManualData() {
        const manualData = {};
        const mobile = document.getElementById('manualMobile').value.trim();
        const email = document.getElementById('manualEmail').value.trim();

        if (mobile) manualData.mobile = mobile;
        if (email) manualData.email = email;

        return manualData;
    }

    // ==================== AUTHENTICATION METHODS ==================== //

    async handleLogin() {
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;

        if (!email || !password) {
            this.showMessage('Please fill all fields', 'error');
            return;
        }

        /* Basic email validation */
        if (!this.isValidEmail(email)) {
            this.showMessage('Please enter a valid email', 'error');
            return;
        }

        const loginBtn = document.getElementById('loginBtn');
        loginBtn.disabled = true;
        loginBtn.textContent = 'Logging in...';

        try {
            if (this.MOCK_MODE) {
                await this.mockLogin(email, password);
            } else {
                await this.realLogin(email, password);
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showMessage('Login failed. Please try again.', 'error');
        } finally {
            loginBtn.disabled = false;
            loginBtn.textContent = 'Login';
        }
    }

    async mockLogin(email, password) {
        // Simulate API delay
        await this.sleep(1000);

        // For testing - accepts any email/password with length >= 6
        if (password.length >= 6) {
            const mockUser = {
                id: 'mock_user_' + Date.now(),
                companyName: 'ABC CA Firm',
                email: email,
                phone: '9876543210',
                location: 'Mumbai, Maharashtra',
                plan: 'PROFESSIONAL',
                planPrice: 1999,
                monthlyLimit: 1000,
                documentsUsed: 45,
                subscriptionStatus: 'ACTIVE', // ACTIVE, EXPIRED, CANCELLED
                subscriptionEndsAt: '2025-12-31',
                createdAt: new Date().toISOString()
            };

            this.authToken = 'mock_token_' + Date.now();
            this.user = mockUser;

            await chrome.storage.local.set({
                authToken: this.authToken,
                user: this.user
            });

            this.showMessage('Login successful!', 'success');
            setTimeout(() => this.showMainScreen(), 1000);
        } else {
            this.showMessage('Invalid credentials. Password must be at least 6 characters.', 'error');
        }
    }

    async realLogin(email, password) {
        const response = await fetch(`${this.API_URL}/account/sign-in`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        if (!response.ok) {
            throw new Error('Login failed');
        }

        const data = await response.json();

        if (data.token) {
            // Check subscription status
            //if (data.user.subscriptionStatus === 'EXPIRED') {
            //     this.showMessage('Your subscription has expired. Please renew.', 'warning');
            //} else if (data.user.subscriptionStatus === 'CANCELLED') {
            //    this.showMessage('Your account has been cancelled. Please contact support.', 'error');
            //    return;
            // }

            this.authToken = data.token;
            this.user = data.user;

            await chrome.storage.local.set({
                authToken: data.token,
                user: data.user
            });

            this.showMessage('Login successful!', 'success');
            setTimeout(() => this.showMainScreen(), 1000);
        } else {
            this.showMessage(data.message || 'Login failed', 'error');
        }
    }

    async handleLogout(silent = false) {
        if (!silent && !confirm('Are you sure you want to logout?')) return;

        await chrome.storage.local.remove(['authToken', 'user']);
        this.authToken = null;
        this.user = null;
        this.uploadedDocuments = [];

        this.showMessage('Logged out successfully', 'success');
        setTimeout(() => this.showAuthScreen(), 1000);
    }

    // ==================== UI NAVIGATION ==================== //

    showAuthScreen() {
        document.getElementById('loadingScreen').style.display = 'none';
        document.getElementById('authScreen').classList.remove('hidden');
        document.getElementById('mainScreen').classList.remove('active');
        document.getElementById('quickFillSection').classList.remove('active');

        /* Clear input fields */
        document.getElementById('loginEmail').value = '';
        document.getElementById('loginPassword').value = '';
    }

    showMainScreen() {
        document.getElementById('loadingScreen').style.display = 'none';
        document.getElementById('authScreen').classList.add('hidden');
        document.getElementById('mainScreen').classList.add('active');
        document.getElementById('quickFillSection').classList.remove('active');

        this.updateUserInfo();
    }

    showMainMenu() {
        document.getElementById('mainScreen').classList.add('active');
        document.getElementById('quickFillSection').classList.remove('active');
    }

    showQuickFillSection() {
        /* Check subscription status first */
        document.getElementById('mainScreen').classList.remove('active');
        document.getElementById('quickFillSection').classList.add('active');

        /* Initial State: Show Domains */
        this.showDomains();
    }

    async showDomains() {
        this.hideAllSections();
        document.getElementById('domainsScreen').style.display = 'block';
        document.getElementById('docSearchInput').style.display = 'block';

        const grid = document.getElementById('domainsGrid');
        grid.innerHTML = '<div class="loading-mini">Loading domains...</div>';

        try {
            const response = await fetch(`${this.API_URL}/domains`, {
                headers: { "Authorization": `Bearer ${this.authToken}` }
            });
            const result = await response.json();

            if (result.success) {
                grid.innerHTML = '';
                result.data.forEach(domain => {
                    const card = document.createElement('div');
                    card.className = 'doc-card';
                    card.innerHTML = `
                        <div class="doc-icon">📁</div>
                        <div class="doc-name">${domain.name}</div>
                    `;
                    card.onclick = () => this.showForms(domain.id, domain.name, domain.forms);
                    grid.appendChild(card);
                });
            } else {
                grid.innerHTML = '<div class="error-text">Failed to load domains</div>';
            }
        } catch (error) {
            console.error('Fetch domains error:', error);
            grid.innerHTML = '<div class="error-text">Error loading domains</div>';
        }
    }

    showForms(domainId, domainName, forms) {
        this.hideAllSections();
        document.getElementById('formsScreen').style.display = 'block';
        document.getElementById('selectedDomainName').textContent = domainName || 'Select Form';

        const backBtn = document.getElementById('backToFormsBtn');
        backBtn.dataset.domainId = domainId;

        const grid = document.getElementById('formsGrid');
        grid.innerHTML = '';

        if (!forms || forms.length === 0) {
            grid.innerHTML = '<div class="empty-state">No forms available in this domain</div>';
            return;
        }

        forms.forEach(form => {
            const card = document.createElement('div');
            card.className = 'doc-card';
            card.innerHTML = `
                <div class="doc-icon">📄</div>
                <div class="doc-name">${form.name}</div>
            `;
            card.onclick = () => this.showFormDetails(form.id);
            grid.appendChild(card);
        });
    }

    async showFormDetails(formId) {
        this.hideAllSections();
        document.getElementById('formDetailsScreen').style.display = 'block';
        document.getElementById('docSearchInput').style.display = 'none';
        document.getElementById('selectedFormId').value = formId;

        const descEl = document.getElementById('formDescription');
        const docsContainer = document.getElementById('requiredDocsContainer');

        descEl.innerHTML = 'Loading form details...';
        docsContainer.innerHTML = '';

        try {
            const response = await fetch(`${this.API_URL}/domains/forms/${formId}`, {
                headers: { "Authorization": `Bearer ${this.authToken}` }
            });
            const result = await response.json();

            if (result.success) {
                const form = result.data;
                document.getElementById('selectedFormTitle').textContent = form.name;
                descEl.textContent = form.description || 'Fill out the required documents to automatically complete this form.';

                // Store required docs for validation
                this.currentFormRequiredDocs = form.required_documents || [];

                // Show required documents as interactive list
                docsContainer.innerHTML = '';

                if (form.required_documents && form.required_documents.length > 0) {
                    console.log("Required Docs:", form.required_documents); // Debug log

                    form.required_documents.forEach(doc => {
                        // Use 'key' as the identifier based on backend response
                        const docTypeId = doc.document_type.key || doc.document_type.slug || 'unknown';
                        console.log(`Processing Doc: ${doc.document_type.name}, TypeID (key): ${docTypeId}`);

                        const row = document.createElement('div');
                        row.className = 'req-doc-row';
                        row.dataset.type = docTypeId;

                        const isUploaded = this.uploadedDocuments.some(d => d.documentType === docTypeId);
                        const statusClass = isUploaded ? 'status-uploaded' : 'status-pending';
                        const statusText = isUploaded ? 'Uploaded' : 'Pending';

                        row.innerHTML = `
                            <div class="req-doc-info">
                                <span class="req-doc-name">${doc.document_type.name}</span>
                                ${doc.is_mandatory ? '<span class="badge-mandatory">Mandatory</span>' : ''}
                            </div>
                            <div class="req-doc-actions">
                                <span class="req-doc-status ${statusClass}">${statusText}</span>
                                <button class="btn-upload-small" ${isUploaded ? 'disabled' : ''}>
                                    ${isUploaded ? '✓' : 'Upload'}
                                </button>
                            </div>
                        `;

                        /* Add click handler for specific upload */
                        const uploadBtn = row.querySelector('.btn-upload-small');
                        if (!isUploaded) {
                            uploadBtn.onclick = () => this.triggerFileUpload(docTypeId);
                        }

                        docsContainer.appendChild(row);
                    });
                } else {
                    docsContainer.innerHTML = '<div class="text-muted">No specific documents required. You can upload any valid document below.</div>';
                }

                // Reset document list when changing forms
                this.uploadedDocuments = [];
                // Update the generic "uploaded documents" list visibility or content if needed
                // For now, we rely on the implementation of updateDocumentList to refresh the UI
                this.updateDocumentList();
            }
        } catch (error) {
            console.error('Fetch form details error:', error);
            descEl.textContent = 'Error loading form details';
        }
    }

    triggerFileUpload(documentType) {
        // Set the hidden input to the selected type
        // Note: documentTypeSelect might be legacy, so we'll store it in a class property or usage 
        // specific to the next file selection
        this.pendingUploadType = documentType;
        document.getElementById('fileInput').click();
    }

    hideAllSections() {
        document.getElementById('domainsScreen').style.display = 'none';
        document.getElementById('formsScreen').style.display = 'none';
        document.getElementById('formDetailsScreen').style.display = 'none';

        // Hide legacy elements if they exist
        const docTypeGrid = document.getElementById('docTypeGrid');
        if (docTypeGrid) docTypeGrid.style.display = 'none';

        const uploadArea = document.getElementById('uploadArea');
        if (uploadArea) uploadArea.style.display = 'none';
    }

    hideLoading() {
        document.getElementById('loadingScreen').style.display = 'none';
    }

    showExpiredWarning() {
        document.getElementById('expiredWarning').style.display = 'block';
    }

    updateUserInfo() {
        if (!this.user) return;

        document.getElementById('userName').textContent = this.user.companyName || this.user.email;
        document.getElementById('userPlan').textContent = this.user.plan + ' PLAN' || 'STARTER PLAN';

        if (this.user.subscriptionEndsAt) {
            const endDate = new Date(this.user.subscriptionEndsAt);
            document.getElementById('subscriptionEndDate').textContent = endDate.toLocaleDateString('en-IN', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        }

        const used = this.user.documentsUsed || 0;
        const limit = this.user.monthlyLimit || 200;
        const percentage = (used / limit) * 100;

        document.getElementById('usageCount').textContent = used;
        document.getElementById('usageLimit').textContent = limit;
        document.getElementById('usageFill').style.width = `${Math.min(percentage, 100)}%`;

        /* Change color based on usage */
        const usageFill = document.getElementById('usageFill');
        if (percentage >= 90) {
            usageFill.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
        } else if (percentage >= 70) {
            usageFill.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
        } else {
            usageFill.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
        }

        /* Show warning if limit reached */
        if (used >= limit) {
            document.getElementById('limitWarning').style.display = 'block';
        } else {
            document.getElementById('limitWarning').style.display = 'none';
        }

        /* Show expired warning */
        if (this.user.subscriptionStatus === 'EXPIRED') {
            this.showExpiredWarning();
        }
    }

    openUpgradePage() {
        chrome.tabs.create({
            url: `${this.WEBSITE_URL}/pricing`
        });
    }

    openRenewPage() {
        chrome.tabs.create({
            url: `${this.WEBSITE_URL}/dashboard`
        });
    }

    // ==================== FILE UPLOAD ==================== //

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.add('dragover');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.remove('dragover');
    }

    handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('uploadArea').classList.remove('dragover');

        const files = Array.from(e.dataTransfer.files);
        this.processFiles(files);
    }

    handleFileSelect(e) {
        const files = Array.from(e.target.files);
        this.processFiles(files);
        e.target.value = '';
    }

    async processFiles(files) {

        const batchDocumentType = this.pendingUploadType;
        this.pendingUploadType = null;

        // Check subscription status
        /* if (this.user.subscriptionStatus === 'EXPIRED') {
             this.showMessage('Please renew your subscription', 'error');
             return;
         }
 
         // Check limit
         if (this.user.documentsUsed >= this.user.monthlyLimit) {
             this.showMessage('Monthly limit exceeded!', 'error');
             return;
         } */

        const validFiles = files.filter(file => {
            const validTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
            return validTypes.includes(file.type);
        });

        if (validFiles.length === 0) {
            this.showMessage('Please upload valid documents (PDF, JPG, PNG)', 'error');
            return;
        }

        /* const remainingLimit = this.user.monthlyLimit - this.user.documentsUsed;
        if (validFiles.length > remainingLimit) {
            this.showMessage(`You can only upload ${remainingLimit} more document(s) this month`, 'error');
            return;
        }*/

        // Limit to 5 documents at once
        if (validFiles.length > 5) {
            this.showMessage('You can upload maximum 5 documents at once', 'warning');
            return;
        }

        for (const file of validFiles) {
            await this.uploadFile(file, batchDocumentType);
        }

        this.updateDocumentList();
    }

    async uploadFile(file, manualType = null) {
        // Check file size (max 10MB)
        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
            this.showMessage(`${file.name} is too large. Max size is 10MB.`, 'error');
            return;
        }

        // Use the specific type if triggered from the list, otherwise generic/auto
        // Note: pendingUploadType is now handled in processFiles and passed here as manualType
        let documentType = manualType;
        if (!documentType || documentType === 'undefined' || documentType === 'null') {
            documentType = 'auto';
        }

        const docData = {
            id: this.generateId(),
            name: file.name,
            type: file.type,
            size: this.formatFileSize(file.size),
            // Store the document type specifically for this file
            documentType: documentType,
            uploadDate: new Date().toISOString()
        };

        const content = await this.readFileAsBase64(file);
        docData.content = content;

        this.uploadedDocuments.push(docData);

        this.showMessage(`Added: ${file.name} (${documentType})`, 'success');
    }

    readFileAsBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    updateDocumentList() {
        const listContainer = document.getElementById('documentList');

        // Also update the required docs status in the form details view
        this.updateRequiredDocsStatus();

        if (this.uploadedDocuments.length === 0) {
            listContainer.innerHTML = '<div class="empty-state">No documents uploaded</div>';
            document.getElementById('doneBtn').disabled = true;
            return;
        }

        document.getElementById('doneBtn').disabled = false;
        listContainer.innerHTML = '';

        this.uploadedDocuments.forEach(doc => {
            const item = document.createElement('div');
            item.className = 'document-item';
            item.innerHTML = `
                <div class="doc-file-info">
                    <div class="document-name" title="${doc.name}">${doc.name}</div>
                    <div class="document-type-badge">${doc.documentType || 'Unknown'}</div>
                </div>
                <button class="btn-delete" data-id="${doc.id}">Delete</button>
            `;

            item.querySelector('.btn-delete').addEventListener('click', () => {
                this.deleteDocument(doc.id);
            });

            listContainer.appendChild(item);
        });
    }

    updateRequiredDocsStatus() {
        // Refresh the status of the required documents list
        const rows = document.querySelectorAll('.req-doc-row');
        rows.forEach(row => {
            const type = row.dataset.type;
            const isUploaded = this.uploadedDocuments.some(d => d.documentType === type);
            const statusBadge = row.querySelector('.req-doc-status');
            const uploadBtn = row.querySelector('.btn-upload-small');

            if (isUploaded) {
                statusBadge.textContent = 'Uploaded';
                statusBadge.className = 'req-doc-status status-uploaded';
                uploadBtn.textContent = 'Remove';
                uploadBtn.disabled = false;
                uploadBtn.style.background = '#fee2e2';
                uploadBtn.style.color = '#ef4444';
                uploadBtn.style.borderColor = '#fecaca';
                uploadBtn.onclick = () => this.deleteDocumentByType(type);
            } else {
                statusBadge.textContent = 'Pending';
                statusBadge.className = 'req-doc-status status-pending';
                uploadBtn.textContent = 'Upload';
                uploadBtn.disabled = false;
                uploadBtn.style.background = ''; // Reset to default
                uploadBtn.style.color = '';
                uploadBtn.style.borderColor = '';
                uploadBtn.onclick = () => this.triggerFileUpload(type);
            }
        });
    }

    deleteDocument(docId) {
        this.uploadedDocuments = this.uploadedDocuments.filter(d => d.id !== docId);
        this.updateDocumentList();
        this.showMessage('Document removed', 'info');
    }

    deleteDocumentByType(docType) {
        const initialCount = this.uploadedDocuments.length;
        this.uploadedDocuments = this.uploadedDocuments.filter(d => d.documentType !== docType);

        if (this.uploadedDocuments.length < initialCount) {
            this.updateDocumentList();
            this.showMessage(`Removed ${docType} document(s)`, 'info');
        }
    }

    // ==================== PROCESS & FILL FORM ==================== //
    //
    // ALPHA STEP 2 CHANGES (this method only):
    //   - REMOVED the Gemini /form-pilot/fill mapping call. content.js already
    //     re-maps everything through Groq in its runFillLoop, so this call was
    //     wasted work (double mapping). Removing it = one mapping brain, clean tokens.
    //   - REMOVED the popup-side scan. content.js scans the page itself inside
    //     its fill loop, so scanning here was redundant.
    //   - ADDED savePocket: the extracted data goes into the worker's in-memory
    //     pocket (keyed by tab), so it persists across pages with NO re-upload.
    //   - Page 1 is triggered by sending fillForm with { userData } only (no
    //     pre-made instructions). content.js does scan -> Groq map -> fill.
    //   - REMOVED the chrome.storage.local 'activeFormData' write. The pocket
    //     (memory, PII-safe) replaces it.
    // ============================================================

    async handleDone() {
        if (this.uploadedDocuments.length === 0) {
            this.showMessage('Please upload at least one document', 'error');
            return;
        }

        // Validate Mandatory Documents
        if (this.currentFormRequiredDocs) {
            const missingDocs = [];
            this.currentFormRequiredDocs.forEach(req => {
                if (req.is_mandatory) {
                    const typeId = req.document_type.key || req.document_type.slug;
                    const isPresent = this.uploadedDocuments.some(d => d.documentType === typeId);
                    if (!isPresent) {
                        missingDocs.push(req.document_type.name);
                    }
                }
            });

            if (missingDocs.length > 0) {
                this.showMessage(`Missing mandatory documents: ${missingDocs.join(', ')}`, 'error');
                return;
            }
        }

        // Check if we're on a valid page
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
            this.showMessage('Please navigate to a form page first', 'warning');
            return;
        }

        const doneBtn = document.getElementById('doneBtn');
        doneBtn.disabled = true;
        doneBtn.textContent = 'Processing...';

        try {
            let extractedData;

            if (this.MOCK_MODE) {
                extractedData = await this.mockExtractDocuments();
            } else {
                extractedData = await this.realExtractDocuments();
            }

            if (extractedData) {

                // Merge any manually-typed data (mobile/email) into the extracted data.
                const manualData = this.getManualData();

                if (extractedData.extractedFields) {
                    extractedData.extractedFields = { ...extractedData.extractedFields, ...manualData };
                }

                // ---- PAYLOAD TRIM (source) ----
                // The mapper only needs the user's REAL values. The raw extraction
                // response also carries baggage the model never uses and which just
                // burns tokens on every mapping call, on every page:
                //   - processedDocuments   : per-document raw data, already merged into extractedFields
                //   - formFillInstructions : stale output from the old popup/Gemini path
                //   - formId               : routing id (kept separately as pocket metadata)
                // So we build a LEAN userData = extractedFields + manual data, and store
                // THAT in the pocket. This slims every mapping call for BOTH Groq and the
                // Gemini path (whichever the worker points at), not just one.
                const leanUserData = {
                    ...(extractedData.extractedFields || {}),
                    ...manualData
                };

                console.log("Lean userData (pocket):", leanUserData);

                // The form the user picked in the popup (may be empty if they just
                // uploaded on an arbitrary page). Stored as metadata in the pocket.
                const selectedFormId = document.getElementById('selectedFormId').value || null;

                // ---- ALPHA: save the LEAN data into the worker's memory pocket ----
                // This is what lets the user upload ONCE and have every subsequent page
                // fill itself, with no re-upload. Keyed by this tab.
                try {
                    const pocketResp = await chrome.runtime.sendMessage({
                        action: 'savePocket',
                        tabId: tab.id,
                        formId: selectedFormId,
                        extractedFields: leanUserData
                    });
                    if (!pocketResp || !pocketResp.success) {
                        console.warn('savePocket did not confirm:', pocketResp);
                    }
                } catch (e) {
                    console.error('savePocket failed:', e);
                    // Not fatal for page 1 (we still trigger the fill below), but multi-page
                    // persistence won't work if this failed. Surface it quietly.
                }

                // ---- Trigger page 1 ----
                // content.js reads userData and runs its own scan -> map -> fill loop.
                // We send ONLY the lean userData now (no instructions, no scan here).
                const finalDataToFill = { userData: leanUserData };

                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        action: 'fillForm',
                        data: finalDataToFill
                    });
                    this.showMessage('Form filling started ✓', 'success');
                } catch (error) {
                    // content script not present yet — inject it, then retry once.
                    console.warn('fillForm send failed, injecting content scripts and retrying:', error);
                    try {
                        await chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            files: ['scanner.js', 'content.js']
                        });
                        await chrome.tabs.sendMessage(tab.id, {
                            action: 'fillForm',
                            data: finalDataToFill
                        });
                        this.showMessage('Form filling started ✓', 'success');
                    } catch (err2) {
                        console.error('Content script error after inject:', err2);
                        this.showMessage('Could not start filling. Please refresh the page and try again.', 'error');
                    }
                }

                /* Update usage count (kept commented, as before) */
                // await this.updateUsageCount(this.uploadedDocuments.length);

                this.uploadedDocuments = [];
                this.updateDocumentList();
                this.updateUserInfo();

                setTimeout(() => {
                    this.showMainMenu();
                }, 2000);
            }
        } catch (error) {
            console.error('Processing error:', error);

            if (error.message.includes('SUBSCRIPTION_EXPIRED')) {
                this.showMessage('Your subscription has expired', 'error');
                this.showExpiredWarning();
            } else {
                this.showMessage('Error processing documents. Please try again.', 'error');
            }
        } finally {
            doneBtn.disabled = false;
            doneBtn.textContent = '✓ Process & Fill Form';
        }
    }

    async mockExtractDocuments() {
        await this.sleep(2000);

        return {
            name: 'Ankit Taphulari',
            email: 'ankit@example.com',
            phone: '9876543210',
            mobile: '9876543210',
            contact: '9876543210',
            address: '123 Main Street, Latur',
            city: 'Latur',
            state: 'Maharashtra',
            pincode: '413512',
            pan: 'ABCDE1234F',
            aadhaar: '1234 5678 9012',
            dob: '01/01/1990',
            dateofbirth: '01-01-1990',
            gender: 'Male',
            fathername: 'Father Name',
            mothername: 'Mother Name'
        };
    }

    async realExtractDocuments() {

        const formData = new FormData();

        /* ALWAYS use batch endpoint as requested */
        const endpoint = '/gemini/process/batch';

        const formId = document.getElementById('selectedFormId').value;
        const fileTypeMap = {};

        /* Always process as a batch, even for a single file */
        for (const doc of this.uploadedDocuments) {
            const blob = await fetch(doc.content).then(r => r.blob());
            formData.append("files", blob, doc.name);
            /* Map original name to its type to send to the backend */
            fileTypeMap[doc.name] = doc.documentType || 'auto';
        }

        if (formId) formData.append("formId", formId);
        formData.append("fileTypes", JSON.stringify(fileTypeMap));

        // Append Manual Data
        const manualData = this.getManualData();
        if (manualData && Object.keys(manualData).length > 0) {
            formData.append("manualData", JSON.stringify(manualData));
        }

        try {
            console.log("Sending Batch Request:", { endpoint, count: this.uploadedDocuments.length, fileTypes: fileTypeMap });

            const response = await fetch(`${this.API_URL}${endpoint}`, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${this.authToken}`
                },
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || "Extraction failed");
            }

            return await response.json();
        } catch (error) {
            console.error("Processing error:", error);
            throw error;
        }
    }

    async updateUsageCount(count) {
        this.user.documentsUsed = (this.user.documentsUsed || 0) + count;
        await chrome.storage.local.set({ user: this.user });

        if (!this.MOCK_MODE) {
            try {
                const response = await fetch(`${this.API_URL}/usage/increment`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.authToken}`
                    },
                    body: JSON.stringify({ count })
                });

                const result = await response.json();
                if (result.success) {
                    this.user.documentsUsed = result.newUsageCount;
                    await chrome.storage.local.set({ user: this.user });
                }
            } catch (error) {
                console.error('Usage update error:', error);
            }
        }
    }

    // ==================== HELPERS ==================== //

    showMessage(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        const messageEl = document.createElement('div');
        messageEl.className = `message ${type}`;
        messageEl.textContent = message;

        container.innerHTML = '';
        container.appendChild(messageEl);

        setTimeout(() => {
            messageEl.remove();
        }, 3000);
    }

    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    generateId() {
        return 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
    new DigitalClerkPopup();
});