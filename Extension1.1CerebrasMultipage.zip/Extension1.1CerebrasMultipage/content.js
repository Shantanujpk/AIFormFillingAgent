/* ============================================================================
 * DigitalClerk — content.js
 * ----------------------------------------------------------------------------
 * ALPHA STOP-LOGIC STEP  (search this file for the tag:  [STOP-LOGIC])
 *
 * WHAT THIS STEP ADDS — the "fall asleep when idle, never ask twice" fix that
 * stops wasted Gemini/mapping API calls on twitchy SPA forms:
 *
 *   1) ASK-ONCE-PER-FIELD  [STOP-LOGIC #1]
 *      Once a field is successfully filled, its id is remembered in
 *      this.filledFieldIds and NEVER sent to the mapper again — even if its
 *      signature changes (cascade dropdowns). Plugs the main cost leak.
 *
 *   2) IDLE -> SLEEP  [STOP-LOGIC #2]
 *      After IDLE_LIMIT consecutive checks that fill nothing, we STOP the 2s
 *      poll and DISCONNECT the observer (goDormant). No looking = no scans =
 *      no accidental API calls while the React page keeps mutating.
 *
 *   3) WAKE ON REAL NAVIGATION  [STOP-LOGIC #3]
 *      popstate or a genuinely different page fingerprint wakes us back up
 *      (wake()) for one more look, so long multi-page forms still work.
 *
 *   4) TERMINAL DETECTION + HARD CALL CAP  [STOP-LOGIC #4]
 *      A submit/thank-you page (isTerminalPage) OR the manual "Done" button
 *      ENDs the session (endSession: wipe pocket, stop poll+observer). Plus a
 *      per-session ceiling MAX_MAPPING_CALLS so a bug can't burn tokens.
 *
 * Everything else (multi-page pocket, auto-fill on load, WAIT/SAFE status,
 * value/visibility guards, cascading multi-pass fill) is unchanged.
 * ==========================================================================*/

class FormFillerContent {
    constructor() {
        this.extractedData = null;
        this.filledFields = new Map();
        // NEW: per-run loop memory (reset each time the loop starts)
        this.loopFilledElements = new WeakSet(); // DOM elements we've already successfully filled this run
        this.loopSeenSignatures = new Map();     // id -> the field signature at the moment we last SENT it to the Brain

        // ==================== ALPHA STEP 3: multi-page state ====================
        // Only the TOP frame drives auto-fill + the SPA observer. With all_frames:true
        // this script also loads inside iframes; without this guard each iframe would
        // fire its own loop. Message handling still works in all frames.
        this.isTopFrame = (window.top === window.self);

        // Re-entrancy lock: true while a fill loop is running. Stops the SPA observer
        // (and any other trigger) from starting a second overlapping loop.
        this.isFilling = false;

        // "Page fingerprint" of the last page we already filled. Used so the SPA
        // observer fills each distinct page ONCE instead of re-firing on every
        // cosmetic DOM mutation. (URL + field count + field ids.)
        this.lastFilledFingerprint = null;

        // Consecutive pages that filled nothing. Tracked now, ACTED ON in the next
        // (stop-logic) step where it becomes pocket-backed. Left here so that step
        // is a small add, not a rewrite.
        this.idlePageCount = 0;

        // ALPHA: robust trigger state (replaces the single debounced observer).
        this._checkTimer = null;       // debounce handle for scheduleAutoFillCheck
        this._pollTimer = null;        // 2s safety-net poll handle
        this._awaitingStable = false;  // true while waiting for a new page to finish rendering
        this._observer = null;         // reference so we can disconnect it when dormant

        // ==================== [STOP-LOGIC] state ====================
        // #1 ask-once: ids of fields we've already filled — never re-sent to the mapper.
        this.filledFieldIds = new Set();

        // #2 idle->sleep: consecutive empty checks, and whether we're asleep.
        this.idleChecks = 0;
        this.dormant = false;
        this.IDLE_LIMIT = 3;           // after this many empty checks in a row, sleep

        // #4 hard money ceiling: max mapping calls per whole session, and a counter.
        this.mappingCallCount = 0;
        this.MAX_MAPPING_CALLS = 40;   // safety cap; a normal multi-page form is well under this
        this.sessionEnded = false;     // true once terminal page / Done ends the session
        // Terminal-detection guards: never "finish" before we've filled anything,
        // and never right after a fill (a click/validation re-render isn't a submit).
        this.hasFilledAnything = false;
        this._lastFillAt = 0;
        // True from the instant Process & Fill is clicked until the fill loop takes
        // over. Suppresses the observer/poll during the pre-loop gap so a click in
        // that window can't trigger an auto-fill check (or terminal detection).
        this._starting = false;

        // [FIX 2] pages we've already given a one-shot dropdown retry (by fingerprint),
        // so we retry each page at most once.
        this._retriedFingerprints = new Set();
        this._lastRunFilled = 0;       // how many fields the most recent loop filled

        this.setupMessageListener();
        this.injectStyles();

        // Auto-fill on load (page 2..N of a multi-page form land here) + SPA watcher.
        // Both are top-frame only.
        this.checkPocketAndFill();     // was checkActiveData(): now reads the worker pocket
        this.setupSpaObserver();

        console.log('Universal Form Filler (Field-First) Loaded' + (this.isTopFrame ? '' : ' [subframe]'));
    }

    // ==================== ALPHA: status UX + field guards ====================

    // Updates the live status line in the floating widget and shows a matching
    // toast. mode: 'wait' (red — do NOT change page), 'safe' (green — ok to move),
    // 'info' (neutral).
    setStatus(text, mode = 'info') {
        if (!this.isTopFrame) return;

        // Make sure the widget exists and is expanded so the user actually sees it.
        this.createFloatingWidget();
        const widget = document.getElementById('dc-floating-widget');
        if (widget) {
            const contentDiv = widget.querySelector('.dc-widget-content');
            const toggleBtn = document.getElementById('dc-toggle-widget');
            if (contentDiv && contentDiv.style.display === 'none') {
                contentDiv.style.display = 'block';
                if (toggleBtn) { toggleBtn.textContent = '▼'; toggleBtn.title = 'Minimize'; }
                widget.classList.remove('minimized');
            }
        }

        const statusEl = document.getElementById('dc-status');
        if (statusEl) {
            const colors = {
                wait: { bg: '#fef3c7', border: '#f59e0b', fg: '#92400e' }, // amber = please wait
                safe: { bg: '#dcfce7', border: '#22c55e', fg: '#166534' }, // green = safe to move
                info: { bg: '#e5e7eb', border: '#9ca3af', fg: '#374151' }
            };
            const c = colors[mode] || colors.info;
            statusEl.textContent = text;
            statusEl.style.background = c.bg;
            statusEl.style.borderLeft = `4px solid ${c.border}`;
            statusEl.style.color = c.fg;
        }

        // Also drive the small "move / wait" banner.
        const bannerEl = document.getElementById('dc-move-banner');
        if (bannerEl) {
            if (mode === 'wait') {
                bannerEl.textContent = '⏳ PLEASE WAIT — do not change the page';
                bannerEl.style.background = '#dc2626';
                bannerEl.style.display = 'block';
            } else if (mode === 'safe') {
                bannerEl.textContent = '✅ SAFE — you can move to the next page';
                bannerEl.style.background = '#16a34a';
                bannerEl.style.display = 'block';
            } else {
                bannerEl.style.display = 'none';
            }
        }
    }

    // True if the field already holds a REAL value (so we should NOT re-fill it).
    hasValue(el) {
        try {
            if (!el) return false;
            const type = (el.type || '').toLowerCase();

            if (type === 'checkbox' || type === 'radio') {
                // For a radio/checkbox group, treat the whole group as "has value"
                // if any member is checked.
                if (el.name) {
                    const safe = (window.CSS && CSS.escape) ? CSS.escape(el.name) : el.name;
                    const group = document.querySelectorAll(`input[name="${safe}"]`);
                    return Array.from(group).some(r => r.checked);
                }
                return !!el.checked;
            }

            // SELECT: this is the important one. Many gov/ASP.NET forms render the
            // placeholder as <option value="0">--Select--</option> or value="-1" /
            // value="Select" — a NON-EMPTY value. The old check (el.value !== '')
            // wrongly treated those as "already filled" and skipped the dropdown, so
            // fields like Gender/Salutation never reached the mapper. Site-agnostic fix:
            // a <select> counts as filled ONLY if a REAL (non-placeholder) option is
            // chosen. Placeholder / first-option / empty-ish => treat as EMPTY (fillable).
            if (el.tagName === 'SELECT') {
                const idx = el.selectedIndex;
                if (idx <= 0) return false;                 // nothing, or first option (usually placeholder)
                const opt = el.options[idx];
                if (!opt) return false;
                const v = String(opt.value || '').trim().toLowerCase();
                const t = String(opt.text || '').trim().toLowerCase();
                // common placeholder sentinels
                if (v === '' || v === '0' || v === '-1') return false;
                if (/^-*\s*(select|choose|please\s*select|none|--\s*select\s*--)\s*-*$/.test(t)) return false;
                return true;                                // a real option is selected
            }

            // Text / textarea / date / etc.
            return String(el.value || '').trim() !== '';
        } catch (e) {
            return false;
        }
    }

    // True if the field is actually visible on the page right now.
    isVisible(el) {
        try {
            if (!el) return false;
            if (el.hidden) return false;
            const style = window.getComputedStyle(el);
            if (!style) return true;
            if (style.display === 'none' || style.visibility === 'hidden') return false;
            if (parseFloat(style.opacity || '1') === 0) return false;
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 && rect.height === 0) return false;
            return true;
        } catch (e) {
            return true; // if unsure, don't over-filter
        }
    }

    // ── LOCAL DROPDOWN MATCHER (deterministic, no LLM) ──────────────────────
    // For each <select> in the batch, try to select an option whose text matches a
    // PLACE value we already hold in userData (city, district, taluka, village,
    // locality, state, and the comma-segments of fulladdress). This nails cascading
    // admin dropdowns (District/Taluka/Village) that the model handles unreliably.
    // Returns a Set of field keys (id or name) that were filled locally.
    localFillSelects(batch, userData) {
        const filled = new Set();
        if (!Array.isArray(batch) || !userData) return filled;

        // Build the pool of place values we have, in priority order.
        const placeValues = this.collectPlaceValues(userData);
        if (placeValues.length === 0) return filled;

        for (const f of batch) {
            const el = this.resolveFieldElement(f);
            if (!el || el.tagName !== 'SELECT') continue;
            if (!this.isVisible(el)) continue;
            if (this.hasValue(el)) continue;          // already has a real selection
            if (el.options.length <= 1) continue;     // no real options yet (cascade not loaded)

            const match = this.findBestOption(el, placeValues);
            if (match) {
                el.value = match.value;
                if (el.selectedIndex !== match.index) el.selectedIndex = match.index;
                this.triggerEvents(el);
                this.highlightField(el);
                const key = el.id || el.name || f.id;
                filled.add(key);
                console.log(`DigitalClerk: local match -> ${key} = "${match.text}"`);
            }
        }
        return filled;
    }

    // Gather candidate place strings from userData (+ split fulladdress into segments).
    collectPlaceValues(userData) {
        const keys = ['city', 'district', 'taluka', 'tehsil', 'village', 'town',
                      'locality', 'subdistrict', 'state'];
        const vals = [];
        const push = (v) => {
            if (v == null) return;
            const s = String(v).trim();
            if (s && !vals.includes(s)) vals.push(s);
        };
        for (const k of Object.keys(userData)) {
            const kl = k.toLowerCase().trim();
            if (keys.some(want => kl === want || kl.includes(want))) push(userData[k]);
        }
        // Split fulladdress into comma segments — taluka/village often live there.
        const fa = userData.fulladdress || userData.address || '';
        if (fa) {
            String(fa).split(/[,\-]/).forEach(seg => {
                const s = seg.trim().replace(/\bcity\b/i, '').trim();
                if (s && s.length >= 3 && !/^\d+$/.test(s)) push(s);
            });
        }
        return vals;
    }

    // Find the option in `select` that best matches any of our place values.
    // Prefers exact (case-insensitive) match; falls back to a clean contains match.
    findBestOption(select, placeValues) {
        const opts = Array.from(select.options).map((o, i) => ({
            index: i, value: o.value,
            text: (o.text || '').trim(),
            norm: (o.text || '').trim().toLowerCase()
        })).filter(o => o.norm && !/^(--)?\s*(select|choose|please)/.test(o.norm));

        // 1) exact match
        for (const pv of placeValues) {
            const p = pv.toLowerCase();
            const hit = opts.find(o => o.norm === p);
            if (hit) return hit;
        }
        // 2) option text contains the place value, or vice-versa (whole-word-ish)
        for (const pv of placeValues) {
            const p = pv.toLowerCase();
            if (p.length < 3) continue;
            const hit = opts.find(o => o.norm === p || o.norm.startsWith(p + ' ') || p.startsWith(o.norm + ' '));
            if (hit) return hit;
        }
        return null;
    }

    // ==================== ALPHA STEP 3: pocket helpers ====================

    // True only if this content script's extension context is still alive. After the
    // extension is reloaded/updated, OLD content scripts left in already-open tabs
    // lose their context; chrome.runtime.id becomes undefined. We use this to make
    // orphaned scripts go SILENT instead of throwing "Extension context invalidated"
    // on every poll tick.
    isExtensionAlive() {
        try {
            return !!(chrome && chrome.runtime && chrome.runtime.id);
        } catch (e) {
            return false;
        }
    }

    // Permanently stop this (orphaned) content script: kill timers + observer so it
    // stops throwing. Called when we detect the context is gone.
    shutdownOrphan() {
        try {
            if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
            if (this._observer) { this._observer.disconnect(); this._observer = null; }
            if (this._checkTimer) { clearTimeout(this._checkTimer); this._checkTimer = null; }
            this.sessionEnded = true;
            console.warn('DigitalClerk: extension context gone — this old content script has stopped. Refresh the page to reactivate.');
        } catch (e) { /* nothing more we can do */ }
    }

    // Ask the background worker for THIS tab's pocket (worker reads the tab id
    // from the message sender, so we don't need to know it here).
    async getPocketFromWorker() {
        // If our context is already dead, don't even try — shut down quietly.
        if (!this.isExtensionAlive()) { this.shutdownOrphan(); return null; }
        try {
            const resp = await chrome.runtime.sendMessage({ action: 'getPocket' });
            if (resp && resp.success) return resp.pocket || null;
        } catch (e) {
            // Most common cause here is a reloaded extension. Go silent instead of
            // spamming the console every 2s.
            if (String(e && e.message).includes('context invalidated') || !this.isExtensionAlive()) {
                this.shutdownOrphan();
            } else {
                console.error('getPocket failed:', e);
            }
        }
        return null;
    }

    // Clear THIS tab's pocket (used by the Clear button).
    async clearPocketInWorker() {
        if (!this.isExtensionAlive()) { this.shutdownOrphan(); return; }
        try {
            await chrome.runtime.sendMessage({ action: 'clearPocket' });
        } catch (e) {
            if (String(e && e.message).includes('context invalidated') || !this.isExtensionAlive()) {
                this.shutdownOrphan();
            } else {
                console.error('clearPocket failed:', e);
            }
        }
    }

    // A cheap fingerprint of the current page's fillable state.
    // Changes when the URL changes OR the set of fields changes (i.e. a new page,
    // whether by reload or SPA swap). Does NOT change on cosmetic mutations, so the
    // SPA observer won't re-fill the same page.
    computePageFingerprint() {
        try {
            if (!(window.DigitalClerkScanner && typeof window.DigitalClerkScanner.scanFormFields === 'function')) {
                return location.href + '::noscanner';
            }
            const fields = window.DigitalClerkScanner.scanFormFields();
            const ids = fields.map(f => f.id).join('|');
            return `${location.href}::${fields.length}::${ids}`;
        } catch (e) {
            return location.href + '::err';
        }
    }

    // The single entry point for auto-filling from the pocket. Guards make it safe
    // to call from load, poll, observer, or popstate.
    // Detects a genuinely-new page, waits for it to finish rendering, then fills.
    async evaluateAndFill(reason) {
        if (!this.isTopFrame) return;
        if (this._starting) return;         // pre-loop gap: loop is about to take over
        if (this.sessionEnded) return;      // [STOP-LOGIC #4] session is over
        if (this.isFilling) return;
        if (this._awaitingStable) return;   // already handling a page transition
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return;

        // BUGFIX: check the pocket FIRST — before any DOM scan. If the user hasn't
        // uploaded/clicked Process & Fill yet, there is no pocket, so we return here
        // WITHOUT ever scanning the page. This stops the "scanning before Process &
        // Fill" behaviour (e.g. right after opening a form / DigiLocker).
        const pocket = await this.getPocketFromWorker();
        if (!pocket || pocket.state === 'ENDED') return;
        const userData = pocket.extractedFields || {};
        if (Object.keys(userData).length === 0) return;

        // Only now (we KNOW there's data) is it worth touching the DOM.

        // [STOP-LOGIC #4] If this looks like a submit/thank-you page, end the session.
        if (this.isTerminalPage()) {
            await this.endSession('terminal-page');
            return;
        }

        // Is this actually a NEW page vs the last one we filled? (URL + field set)
        const fp = this.computePageFingerprint();
        if (fp === this.lastFilledFingerprint) return;

        // Wait until the field set is STABLE (unchanged across two checks) and
        // non-empty, so we don't fire before the page finished rendering AND we
        // aren't starved by ambient background mutations.
        this._awaitingStable = true;
        this.setStatus('🔍 New page detected — waiting for it to load…', 'wait');
        const ready = await this.waitForFieldsStable();
        this._awaitingStable = false;

        if (!ready) return;                 // never stabilized / no fields
        if (this.isFilling) return;         // a fill started meanwhile (e.g. popup)

        // Re-confirm it's still a new page (user may have navigated again).
        if (this.computePageFingerprint() === this.lastFilledFingerprint) return;

        this.extractedData = { userData };
        this.createFloatingWidget();
        console.log(`DigitalClerk: auto-fill triggered (${reason}).`);
        await this.runFillLoop(userData);

        // [FIX 2] Dropdown-only pages: if a brand-new page filled NOTHING, its cascade
        // children may not have rendered yet. Give it ONE more try after a short delay.
        // Guarded by fingerprint so each page retries at most once (no loops).
        if (this._lastRunFilled === 0 && !this.dormant && !this.sessionEnded) {
            const fpNow = this.computePageFingerprint();
            if (!this._retriedFingerprints.has(fpNow)) {
                this._retriedFingerprints.add(fpNow);
                this.lastFilledFingerprint = null;   // allow this page to be re-evaluated
                console.log('DigitalClerk: page filled nothing — scheduling one dropdown retry.');
                setTimeout(() => this.scheduleAutoFillCheck('dropdown-retry'), 1500);
            }
        }
    }

    // Polls the scannable field count until it is > 0 AND unchanged across two
    // consecutive checks (page stopped rendering), up to a timeout.
    waitForFieldsStable(intervalMs = 500, timeoutMs = 8000) {
        return new Promise(resolve => {
            const start = Date.now();
            let last = -1;
            const tick = () => {
                let count = 0;
                try {
                    if (window.DigitalClerkScanner && typeof window.DigitalClerkScanner.scanFormFields === 'function') {
                        count = window.DigitalClerkScanner.scanFormFields().length;
                    }
                } catch (e) { count = 0; }

                if (count > 0 && count === last) { resolve(true); return; }   // stable
                if (Date.now() - start > timeoutMs) { resolve(count > 0); return; }
                last = count;
                setTimeout(tick, intervalMs);
            };
            tick();
        });
    }

    // Debounced "something changed — check if it's a new page to fill."
    scheduleAutoFillCheck(reason) {
        if (!this.isTopFrame) return;
        if (this._checkTimer) clearTimeout(this._checkTimer);
        this._checkTimer = setTimeout(() => this.evaluateAndFill(reason), 350);
    }

    // Runs on load. On page 2..N of a multi-page form, the pocket already exists,
    // so this auto-fills without any re-upload.
    async checkPocketAndFill() {
        if (!this.isTopFrame) return;
        this.scheduleAutoFillCheck('page-load');
    }

    // Trigger system: observer (responsive) + popstate + a 2s safety-net poll.
    // The poll is the key reliability fix — even if the observer's debounce is
    // starved by ambient SPA mutations, within ~2s the poll notices the page
    // changed and kicks off a fill.
    setupSpaObserver() {
        if (!this.isTopFrame || !document.body) return;

        // Disconnect any previous observer before making a new one (wake() reuses this).
        if (this._observer) { this._observer.disconnect(); this._observer = null; }

        this._observer = new MutationObserver(() => {
            if (this._starting || this.isFilling || this._awaitingStable || this.dormant || this.sessionEnded) return;
            this.scheduleAutoFillCheck('dom-change');
        });
        this._observer.observe(document.body, { childList: true, subtree: true });

        // [STOP-LOGIC #3] Register the popstate wake listener ONCE. A real navigation
        // both wakes us from a nap and kicks a fresh check.
        if (!this._popstateBound) {
            this._popstateBound = true;
            window.addEventListener('popstate', () => {
                if (this.sessionEnded) return;
                if (this.dormant) this.wake('popstate');
                else this.scheduleAutoFillCheck('popstate');
            });
        }

        this._pollTimer = setInterval(async () => {
            // If the extension was reloaded, stop this orphaned poll instead of
            // throwing every 2 seconds.
            if (!this.isExtensionAlive()) { this.shutdownOrphan(); return; }
            if (this._starting || this.isFilling || this._awaitingStable || this.dormant || this.sessionEnded) return;

            // BUGFIX: don't scan on every poll tick. First do a cheap pocket check;
            // only fingerprint (which scans the DOM) if there's actually data to fill.
            const pocket = await this.getPocketFromWorker();
            if (!pocket || pocket.state === 'ENDED') return;
            if (!pocket.extractedFields || Object.keys(pocket.extractedFields).length === 0) return;

            const fp = this.computePageFingerprint();
            if (fp !== this.lastFilledFingerprint) {
                this.scheduleAutoFillCheck('poll');
            }
        }, 2000);
    }

    createFloatingWidget() {
        if (document.getElementById('dc-floating-widget')) return;

        const widget = document.createElement('div');
        widget.id = 'dc-floating-widget';
        widget.classList.add('minimized');

        widget.innerHTML = `
            <div class="dc-widget-header">
                <span class="dc-logo">📄 DigitalClerk</span>
                <div class="dc-header-controls">
                    <button id="dc-toggle-widget" title="Maximize">▲</button>
                    <button id="dc-close-widget" title="Close">×</button>
                </div>
            </div>
            <div class="dc-widget-content" style="display: none;">
                <div id="dc-move-banner" style="display:none; padding:6px 8px; border-radius:6px; color:white; font-weight:700; font-size:11px; text-align:center; margin-bottom:9px;"></div>
                <div id="dc-status" style="padding:8px 10px; border-radius:6px; font-size:12px; line-height:1.35; background:#e5e7eb; border-left:4px solid #9ca3af; color:#374151; margin-bottom:10px;">Data ready. Fill will start automatically on each page.</div>
                <p style="font-size:11px; color:#6b7280;">Wait for the green “SAFE” banner before moving to the next page.</p>
                <div class="dc-widget-actions">
                    <button id="dc-done-btn" class="dc-btn-primary">Done</button>
                    <button id="dc-clear-btn" class="dc-btn-secondary">Clear</button>
                </div>
            </div>
        `;

        document.body.appendChild(widget);

        const contentDiv = widget.querySelector('.dc-widget-content');
        const toggleBtn = document.getElementById('dc-toggle-widget');

        toggleBtn.addEventListener('click', () => {
            const isHidden = contentDiv.style.display === 'none';
            if (isHidden) {
                contentDiv.style.display = 'block';
                toggleBtn.textContent = '▼';
                toggleBtn.title = 'Minimize';
                widget.classList.remove('minimized');
            } else {
                contentDiv.style.display = 'none';
                toggleBtn.textContent = '▲';
                toggleBtn.title = 'Maximize';
                widget.classList.add('minimized');
            }
        });

        document.getElementById('dc-clear-btn').addEventListener('click', () => {
            this.clearActiveData();
        });

        // [STOP-LOGIC #4] Manual Done: user says the form is finished -> end session.
        const doneBtn = document.getElementById('dc-done-btn');
        if (doneBtn) {
            doneBtn.addEventListener('click', () => {
                this.endSession('manual-done');
                this.showNotification('Done — filling stopped for this form.', 'info');
            });
        }

        document.getElementById('dc-close-widget').addEventListener('click', () => {
            widget.remove();
        });
    }

    // Clear now wipes the POCKET (worker/memory) instead of the old disk key.
    async clearActiveData() {
        await this.clearPocketInWorker();
        this.extractedData = null;
        this.lastFilledFingerprint = null;
        const widget = document.getElementById('dc-floating-widget');
        if (widget) widget.remove();
        this.showNotification('Data cleared', 'info');
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            console.log("Action received:", request.action);
            switch (request.action) {
                case 'fillForm':
                    // Seal the pre-loop gap: from this instant until runFillLoop takes
                    // over, suppress the observer/poll so a stray click can't fire an
                    // auto-fill check or terminal detection. Failsafe clears it so it
                    // can never wedge the triggers if the loop never starts.
                    this._starting = true;
                    setTimeout(() => { this._starting = false; }, 8000);

                    // [FIX 1] A new Process & Fill = a fresh run. Reset all leftover
                    // state from any previous run (filled ids, fingerprint, dormant/
                    // ended flags) and restart the triggers — this is what "Clear then
                    // try again" was doing manually.
                    this.resetSession();

                    this.extractedData = request.data;
                    this.createFloatingWidget();

                    setTimeout(() => {
                        const userData = (request.data && (request.data.userData || request.data.extractedFields))
                            ? (request.data.userData || request.data.extractedFields)
                            : request.data;

                        if (userData) {
                            this.runFillLoop(userData);
                        } else {
                            const pageData = this.getPageData(this.extractedData, 1);
                            if (pageData) this.fillFormWithData(pageData);
                        }
                    }, 500);

                    sendResponse({ success: true });
                    break;

                case 'getExtractedData':
                    sendResponse({ data: this.extractedData });
                    break;
            }
            return true;
        });
    }

    getPageData(data, pageNum) {
        if (!data) return null;

        let potentialInstructions = null;
        if (Array.isArray(data)) {
            potentialInstructions = data;
        } else if (data.formFillInstructions && Array.isArray(data.formFillInstructions)) {
            potentialInstructions = data.formFillInstructions;
        }

        if (potentialInstructions && potentialInstructions.length > 0) {
            if ('pageNumber' in potentialInstructions[0]) {
                const filtered = potentialInstructions.filter(item => item.pageNumber == pageNum);
                return { formFillInstructions: filtered };
            }
        }

        const index = pageNum - 1;

        if (Array.isArray(data)) {
            return data[index] || null;
        }
        if (data[index] && typeof data[index] === 'object') {
            return data[index];
        }
        if (data.pages && Array.isArray(data.pages)) {
            return data.pages[index] || null;
        }
        if (data.documents && Array.isArray(data.documents)) {
            return data.documents[index] || null;
        }
        if (pageNum === 1) {
            return data;
        }
        return null;
    }

    // ==================== CORE LOGIC ====================

    // ==================== THE FILL LOOP (single-click engine) ====================

    async runFillLoop(userData) {
        // Re-entrancy guard: never run two loops at once (auto-fill + observer + popup).
        if (this.isFilling) {
            console.log('DigitalClerk: fill already in progress, ignoring new trigger.');
            return;
        }
        this.isFilling = true;
        this._starting = false;   // loop has taken over; isFilling now guards the triggers

        // Reset memory for THIS run so a second click / new page starts clean.
        this.loopFilledElements = new WeakSet();
        this.loopSeenSignatures = new Map();

        const MAX_ITERATIONS = 20;        // raised: cascade waits use extra passes
        const MAX_TIME_MS = 60000;        // raised: give slow website cascades time
        const MAX_EMPTY_STREAK = 4;       // empty checks in a row before we conclude the cascade is done
        let emptyStreak = 0;
        const startTime = Date.now();
        let totalFilled = 0;

        try {
            if (!(window.DigitalClerkScanner && typeof window.DigitalClerkScanner.scanFormFields === 'function')) {
                this.showNotification('Scanner not ready.', 'warning');
                return;
            }

            // UX: tell the user we've started and it's NOT safe to change page yet.
            this.setStatus('🔍 Scanning form…', 'wait');

            for (let iteration = 1; iteration <= MAX_ITERATIONS; iteration++) {
                if (Date.now() - startTime > MAX_TIME_MS) {
                    console.log('DigitalClerk: time cap reached, stopping loop.');
                    break;
                }

                // 1. Re-read the WHOLE form fresh every pass.
                const allFields = window.DigitalClerkScanner.scanFormFields();
                if (!allFields || allFields.length === 0) break;

                // 2. Decide which fields are worth sending to the Brain this pass.
                const batch = allFields.filter(f => {
                    const el = this.resolveFieldElement(f);

                    // [STOP-LOGIC #1] ASK-ONCE: if we've already filled this field id
                    // in this session, NEVER send it to the mapper again — even if its
                    // signature changed (cascade wiggle). This is the main cost plug.
                    if (this.filledFieldIds.has(f.id)) return false;

                    // Already filled by us in THIS run.
                    if (el && this.loopFilledElements.has(el)) return false;

                    // ALPHA: skip fields that already have a value (either we filled
                    // them on a previous page/visit, or the user typed them manually).
                    // This stops re-mapping/re-filling when you navigate BACK to a page,
                    // and never overwrites the user's own input.
                    if (el && this.hasValue(el)) return false;

                    // ALPHA: skip fields that aren't actually visible on screen. SPA forms
                    // often keep NEXT-page fields in the DOM but hidden — without this we'd
                    // map and fill fields for pages the user hasn't opened yet.
                    if (el && !this.isVisible(el)) return false;

                    const lastSig = this.loopSeenSignatures.get(f.id);
                    if (lastSig !== undefined && lastSig === f.signature) return false;
                    return true;
                });

                // 3. Nothing new right now -> the page may still be loading a cascade
                //    child (e.g. District options load a moment after State is set).
                //    A fast model outruns the website, so DON'T quit on the first empty
                //    pass. Wait and re-check a few times; only stop after several empty
                //    checks in a row (the cascade has truly finished).
                if (batch.length === 0) {
                    emptyStreak++;
                    if (emptyStreak >= MAX_EMPTY_STREAK) {
                        console.log(`DigitalClerk: pass ${iteration} — ${emptyStreak} empty checks, cascade settled. Loop complete.`);
                        break;
                    }
                    console.log(`DigitalClerk: pass ${iteration} nothing yet (empty ${emptyStreak}/${MAX_EMPTY_STREAK}) — waiting for cascade…`);
                    this.setStatus('⏳ Waiting for dependent fields to load…', 'wait');
                    await this.waitForCascade();   // longer, cascade-aware wait
                    continue;
                }
                emptyStreak = 0;   // found something -> reset the empty counter

                // ── LOCAL DROPDOWN MATCH (no LLM) ──────────────────────────────
                // Cascading admin dropdowns (District/Taluka/Village/State) are where
                // the model is unreliable. But it's a deterministic problem: if the
                // dropdown has an option whose text equals a place value we already
                // hold in userData, we can just select it ourselves — instantly, and
                // 100% correctly. We do this BEFORE the model call and drop any field
                // we fill locally from the batch, so we don't waste a mapping call on it.
                try {
                    const locallyFilled = this.localFillSelects(batch, userData);
                    if (locallyFilled.size > 0) {
                        totalFilled += locallyFilled.size;
                        for (const fid of locallyFilled) this.filledFieldIds.add(fid);
                        // Remove locally-filled fields from the batch sent to the model.
                        for (let i = batch.length - 1; i >= 0; i--) {
                            const f = batch[i];
                            const el = this.resolveFieldElement(f);
                            const key = (el && (el.id || el.name)) || f.id;
                            if (locallyFilled.has(key)) batch.splice(i, 1);
                        }
                        console.log(`DigitalClerk: locally filled ${locallyFilled.size} dropdown(s) without the model.`);
                        // Filling a select may trigger the NEXT cascade child -> let it load.
                        await this.waitForCascade();
                    }
                } catch (e) {
                    console.warn('DigitalClerk: local dropdown match failed (non-fatal):', e);
                }

                // If the local match handled everything this pass, skip the model call.
                if (batch.length === 0) {
                    continue;
                }

                // [STOP-LOGIC #4] HARD MONEY CEILING: never exceed MAX_MAPPING_CALLS
                // mapping calls in one session, no matter what. Safety net against runaway loops.
                if (this.mappingCallCount >= this.MAX_MAPPING_CALLS) {
                    console.warn(`DigitalClerk: mapping-call cap (${this.MAX_MAPPING_CALLS}) reached — stopping to protect tokens.`);
                    this.setStatus('⚠️ Reached this session’s fill limit. Click Clear to reset.', 'info');
                    break;
                }

                // Record that we're sending these now.
                batch.forEach(f => this.loopSeenSignatures.set(f.id, f.signature));

                // UX: matching data to fields via the AI — please wait.
                this.setStatus('🧠 Matching your data to the form… please wait', 'wait');

                // 4. Ask the Brain to map this batch.
                // DYNAMIC CHUNKING: a small form goes out as ONE call (cheap). A big form is
                // split into chunks so the LLM maps each chunk reliably (large single calls make
                // it drop/skip fields inconsistently). We only pay extra calls when the form is big.
                const CHUNK_THRESHOLD = 20;   // at or below this many fields -> single call (no extra cost)
                const CHUNK_SIZE = 20;        // when splitting, fields per call

                const allInstructions = [];   // collect instructions across all chunks this pass

                if (batch.length <= CHUNK_THRESHOLD) {
                    // SMALL form -> one call, exactly like before. No added cost.
                    let response;
                    try {
                        this.mappingCallCount++;   // [STOP-LOGIC #4] count every mapping call
                        response = await chrome.runtime.sendMessage({
                            action: 'apiFillForm',
                            fields: batch,
                            userData: userData
                        });
                    } catch (e) {
                        console.error('DigitalClerk: fill request failed', e);
                        break;
                    }
                    if (response && response.success && Array.isArray(response.instructions)) {
                        allInstructions.push(...response.instructions);
                    }
                } else {
                    // BIG form -> split into chunks so the LLM stays consistent.
                    for (let i = 0; i < batch.length; i += CHUNK_SIZE) {
                        if (this.mappingCallCount >= this.MAX_MAPPING_CALLS) break; // respect cap mid-chunk
                        const chunk = batch.slice(i, i + CHUNK_SIZE);
                        let response;
                        try {
                            this.mappingCallCount++;   // [STOP-LOGIC #4] count every mapping call
                            response = await chrome.runtime.sendMessage({
                                action: 'apiFillForm',
                                fields: chunk,
                                userData: userData
                            });
                        } catch (e) {
                            console.error('DigitalClerk: chunk request failed', e);
                            continue;   // skip this chunk, keep going with the rest
                        }
                        if (response && response.success && Array.isArray(response.instructions)) {
                            allInstructions.push(...response.instructions);
                        }
                    }
                }

                console.log(`DigitalClerk: pass ${iteration} -> ${allInstructions.length} instructions from ${batch.length} fields`);

                // If nothing came back this pass, settle and retry.
                if (allInstructions.length === 0) {
                    console.warn('DigitalClerk: no instructions this pass.');
                    await this.waitForSettle();
                    continue;
                }

                // 5. Apply all collected instructions; remember which elements got filled.
                this.setStatus('✍️ Filling fields…', 'wait');
                const filledEls = this.applyInstructions(allInstructions);
                filledEls.forEach(el => this.loopFilledElements.add(el));
                // [STOP-LOGIC #1] permanently remember every filled field id so it's
                // never sent to the mapper again this session.
                for (const inst of allInstructions) {
                    if (inst && inst.fieldId) {
                        const el = document.querySelector(inst.fieldId);
                        if (el && (el.id || el.name)) this.filledFieldIds.add(el.id || el.name);
                    }
                }
                totalFilled += filledEls.length;

                // 6. Wait for the page to settle (cascades fire here) before scanning again.
                await this.waitForSettle();
            }

            if (totalFilled > 0) {
                this.hasFilledAnything = true;
                this._lastFillAt = Date.now();
                this.showNotification(`✓ Filled ${totalFilled} field(s)`);
                this.setStatus(`✅ Page filled (${totalFilled}). SAFE to go to the next page. Fill any remaining fields manually first.`, 'safe');
                this.idlePageCount = 0;
                this.idleChecks = 0;      // [STOP-LOGIC #2] real work happened -> reset idle
            } else {
                this.showNotification('Could not match any fields', 'warning');
                this.setStatus('ℹ️ Nothing to fill here. SAFE to continue — fill this page manually if needed.', 'safe');
                this.idlePageCount++;
                this.idleChecks++;        // [STOP-LOGIC #2] nothing filled -> count toward sleep
                if (this.idleChecks >= this.IDLE_LIMIT) {
                    this.goDormant();     // [STOP-LOGIC #2] been quiet too long -> sleep
                }
            }
        } finally {
            // Always release the lock and mark this page as handled, even on error,
            // so the SPA observer won't immediately re-fire on the same page.
            this.isFilling = false;
            this._lastRunFilled = totalFilled;   // [FIX 2] how many we filled this run
            this.lastFilledFingerprint = this.computePageFingerprint();
        }
    }

    // ==================== [STOP-LOGIC #2/#3/#4] sleep / wake / end ====================

    // [FIX 1] Reset ALL per-run state so a new Process & Fill starts completely fresh,
    // and restart the triggers (they may have been stopped by dormancy/endSession).
    resetSession() {
        this.filledFieldIds = new Set();
        this.loopFilledElements = new WeakSet();
        this.loopSeenSignatures = new Map();
        this.lastFilledFingerprint = null;
        this.idleChecks = 0;
        this.idlePageCount = 0;
        this.mappingCallCount = 0;
        this.dormant = false;
        this.sessionEnded = false;
        this.hasFilledAnything = false;
        this._lastFillAt = 0;
        this._retriedFingerprints = new Set();
        this._lastRunFilled = 0;
        // Rebuild observer + poll (setupSpaObserver clears old ones first).
        this.setupSpaObserver();
        console.log('DigitalClerk: session reset (new Process & Fill).');
    }

    // [STOP-LOGIC #2] Go to sleep: stop the 2s poll and disconnect the observer so
    // the twitchy page can churn without costing us scans or accidental API calls.
    goDormant() {
        if (this.dormant) return;
        this.dormant = true;
        if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
        if (this._observer) { this._observer.disconnect(); this._observer = null; }
        console.log('DigitalClerk: idle — going dormant (poll + observer stopped).');
        this.setStatus('💤 Idle. Filling paused. It will resume when you open a new page.', 'info');
    }

    // [STOP-LOGIC #3] Wake back up (called by popstate / real navigation). Rebuilds
    // the observer + poll so a long multi-page form keeps working after a nap.
    wake(reason) {
        if (this.sessionEnded) return;
        if (!this.dormant) return;
        this.dormant = false;
        this.idleChecks = 0;
        console.log(`DigitalClerk: waking up (${reason}).`);
        this.setupSpaObserver();          // rebuild observer + poll
        this.scheduleAutoFillCheck(reason);
    }

    // [STOP-LOGIC #4] End the session for good: wipe pocket, stop everything.
    async endSession(reason) {
        if (this.sessionEnded) return;
        this.sessionEnded = true;
        console.log(`DigitalClerk: ending session (${reason}).`);
        if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
        if (this._observer) { this._observer.disconnect(); this._observer = null; }
        if (this._checkTimer) { clearTimeout(this._checkTimer); this._checkTimer = null; }
        await this.clearPocketInWorker();
        this.setStatus('🏁 Form session finished.', 'safe');
    }

    // [STOP-LOGIC #4] Are we on a genuine POST-SUBMIT confirmation page?
    // Rewritten to fix premature endings: the old version matched field LABELS
    // ("acknowledgement number", "reference number") that live on gov forms the
    // whole time, so any DOM mutation (a click, a validation message) re-tripped
    // it. Now it requires a real state transition into a result page.
    isTerminalPage() {
        try {
            // (a) Never end mid-activity — this churn is ours or the user's, not a submit.
            if (this.isFilling || this._awaitingStable) return false;

            // (b) A session that never filled anything can't be "finished".
            if (!this.hasFilledAnything) return false;

            // (c) Cooldown: ignore for a few seconds after our last fill, so a click
            //     or framework re-render right after filling isn't read as a result.
            if (Date.now() - (this._lastFillAt || 0) < 4000) return false;

            // (d) STRUCTURAL GATE — the decisive one. A real acknowledgement/thank-you
            //     page has essentially NO form left to fill; a mid-fill gov form always
            //     has many live fields. If the form is still here, we are NOT terminal,
            //     no matter what words are on the page.
            let liveFieldCount = 0;
            try {
                if (window.DigitalClerkScanner &&
                    typeof window.DigitalClerkScanner.scanFormFields === 'function') {
                    liveFieldCount = window.DigitalClerkScanner.scanFormFields().length;
                }
            } catch (e) { liveFieldCount = 0; }

            const liveInputs = Array.from(document.querySelectorAll(
                'input:not([type=hidden]):not([disabled]):not([readonly]), ' +
                'select:not([disabled]), textarea:not([disabled])'
            )).filter(el => {
                const t = (el.type || '').toLowerCase();
                if (t === 'submit' || t === 'button' || t === 'search') return false;
                const r = el.getBoundingClientRect();
                return r.width > 0 && r.height > 0;   // visible
            });

            if (liveFieldCount > 2 || liveInputs.length > 2) return false;  // form still present

            // (e) CONTENT GATE — only strong, result-style confirmations. These do not
            //     appear as field labels. Bare "reference/acknowledgement number" is
            //     deliberately NOT here (it's a label on live forms).
            const bodyText = document.body.innerText || '';
            const txt = bodyText.toLowerCase();
            const strongPhrases = [
                'application submitted successfully', 'successfully submitted',
                'has been submitted successfully', 'your application has been submitted',
                'application has been received', 'thank you for your submission',
                'thank you for applying', 'registration successful',
                'registration completed successfully', 'payment successful',
                'transaction successful', 'successfully registered'
            ];
            const hasStrongPhrase = strongPhrases.some(s => txt.includes(s));

            // An ack/ref/application number that is SHOWING a value (digits right after
            // it), i.e. displaying a result — not a label requesting one to be typed.
            const ackWithValue = /(acknowledg(?:e)?ment|reference|application|registration)\s*(?:no\.?|number|id)?\s*[:#-]?\s*[A-Z0-9]{6,}/i.test(bodyText);

            return hasStrongPhrase || ackWithValue;
        } catch (e) {
            return false;
        }
    }

    applyInstructions(instructions) {
        const filled = [];
        for (const inst of instructions) {
            try {
                const selector = inst.fieldId;
                if (!selector) continue;
                const field = document.querySelector(selector);
                if (!field) {
                    console.warn(`Field not found for selector: ${selector}`);
                    continue;
                }

                let ok = false;
                if (inst.fieldType === 'date' && inst.datePattern) {
                    ok = this.fillField(field, this.transformDate(inst.value, inst.datePattern));
                } else {
                    ok = this.fillField(field, inst.value);
                }

                if (ok) filled.push(field);
            } catch (e) {
                console.error("Error applying instruction", inst, e);
            }
        }
        return filled;
    }

    resolveFieldElement(field) {
        if (!field || !field.id) return null;
        const safe = (window.CSS && CSS.escape) ? CSS.escape(field.id) : field.id;
        try {
            return document.querySelector(`#${safe}, [name="${safe}"], [data-dc-id="${safe}"]`);
        } catch (e) {
            return null;
        }
    }

    waitForSettle(quietMs = 700, maxMs = 3000) {
        return new Promise(resolve => {
            let quietTimer = null;
            let observer = null;

            const done = () => {
                if (observer) observer.disconnect();
                if (quietTimer) clearTimeout(quietTimer);
                resolve();
            };

            observer = new MutationObserver(() => {
                if (quietTimer) clearTimeout(quietTimer);
                quietTimer = setTimeout(done, quietMs);
            });

            observer.observe(document.body, { childList: true, subtree: true, attributes: true });

            quietTimer = setTimeout(done, quietMs);
            setTimeout(done, maxMs);
        });
    }

    // Cascade-aware wait: used when a pass found nothing to fill, to give the WEBSITE
    // time to load a dependent field (e.g. District options after State is set). A fast
    // model outruns the site; this waits up to ~2.5s but RESOLVES EARLY the moment a new
    // fillable option/field appears, so it stays snappy when nothing is loading.
    waitForCascade(maxMs = 2500, pollMs = 300) {
        return new Promise(resolve => {
            const start = Date.now();

            // Snapshot: total number of <option>s across all selects + total field count.
            const snapshot = () => {
                let optCount = 0;
                const selects = document.querySelectorAll('select');
                for (const s of selects) optCount += s.options.length;
                const fieldCount = document.querySelectorAll('input, select, textarea').length;
                return optCount + ':' + fieldCount;
            };

            const baseline = snapshot();

            const tick = () => {
                // If the option/field landscape changed, a cascade child arrived -> go now.
                if (snapshot() !== baseline) { resolve(); return; }
                if (Date.now() - start > maxMs) { resolve(); return; }
                setTimeout(tick, pollMs);
            };
            setTimeout(tick, pollMs);
        });
    }

    async fillFormWithData(rawData) {
        this._starting = false;   // legacy fill path has taken over
        console.log("Raw Data:", rawData);
        if (!rawData) return;

        if (rawData.formFillInstructions && rawData.formFillInstructions.length > 0) {
            this.fillFormByInstructions(rawData.formFillInstructions);
            return;
        }

        const data = this.normalizeData(rawData.extractedFields || rawData);
        console.log("Normalized Data:", data);

        if (Object.keys(data).length === 0) {
            this.showNotification('No valid data found to fill', 'warning');
            return;
        }

        const allFields = Array.from(document.querySelectorAll('input, select, textarea'))
            .filter(field => !this.shouldSkipField(field));

        let totalFilled = 0;
        for (const field of allFields) {
            const fieldKey = this.identifyField(field);
            if (fieldKey && data[fieldKey]) {
                const filled = this.fillField(field, data[fieldKey]);
                if (filled) totalFilled++;
            }
        }

        if (totalFilled > 0) {
            this.showNotification(`✓ Filled ${totalFilled} field(s)`);
        } else {
            this.showNotification('Could not match any fields', 'warning');
        }
    }

    async fillFormByInstructions(instructions) {
        console.log("Filling by instructions:", instructions);
        let totalFilled = 0;
        const failedInstructions = [];

        const processSingleInstruction = (inst) => {
            try {
                const selector = inst.fieldId;
                if (!selector) return false;

                const field = document.querySelector(selector);

                if (inst.fieldOptions) {
                    const mapped = this.fillByMapping(field, inst.value, inst.fieldOptions, selector);
                    if (mapped) return true;
                }

                if (inst.fieldType === 'date' && inst.datePattern) {
                    const transformedValue = this.transformDate(inst.value, inst.datePattern);
                    if (field) {
                        return this.fillField(field, transformedValue);
                    }
                }

                if (field) {
                    return this.fillField(field, inst.value);
                } else {
                    console.warn(`Field not found for selector: ${selector}`);
                    return false;
                }
            } catch (e) {
                console.error("Error filling by instruction", inst, e);
                return false;
            }
        };

        for (const inst of instructions) {
            const success = processSingleInstruction(inst);
            if (success) {
                totalFilled++;
            } else {
                failedInstructions.push(inst);
            }
        }

        if (failedInstructions.length > 0) {
            console.log(`Retrying ${failedInstructions.length} failed instructions after delay...`);
            await new Promise(resolve => setTimeout(resolve, 2000));

            for (const inst of failedInstructions) {
                const success = processSingleInstruction(inst);
                if (success) {
                    totalFilled++;
                    console.log(`Successfully filled ${inst.fieldId} on retry`);
                }
            }
        }

        if (totalFilled > 0) {
            this.showNotification(`✓ Form filled using ${totalFilled} exact matches`);
        } else {
            this.showNotification('Selectors did not match any fields', 'warning');
        }
    }

    fillByMapping(field, extractedValue, options, defaultSelector) {
        if (!options || !Array.isArray(options)) return false;

        const dataVal = String(extractedValue).toLowerCase().trim();
        const mapping = options.find(m => String(m.extractedValue).toLowerCase().trim() === dataVal);

        if (!mapping) return false;

        if (mapping.targetSelector) {
            const target = document.querySelector(mapping.targetSelector);
            if (target) {
                if (target.type === 'radio' || target.type === 'checkbox') {
                    target.checked = true;
                } else if (target.tagName === 'OPTION') {
                    const select = target.closest('select');
                    if (select) {
                        target.selected = true;
                        this.triggerEvents(select);
                        this.highlightField(select);
                        return true;
                    }
                }
                this.triggerEvents(target);
                this.highlightField(target);
                return true;
            }
        }

        if (mapping.targetValue) {
            const val = mapping.targetValue;

            if (field && (field.type === 'radio' || field.name)) {
                const name = field.name;
                const radio = document.querySelector(`input[name="${name}"][value="${val}"]`);
                if (radio) {
                    radio.checked = true;
                    this.triggerEvents(radio);
                    this.highlightField(radio);
                    return true;
                }
            }

            if (field && field.tagName === 'SELECT') {
                for (let opt of field.options) {
                    if (opt.value === val) {
                        field.value = val;
                        this.triggerEvents(field);
                        this.highlightField(field);
                        return true;
                    }
                }
            }
        }

        if (mapping.targetText && field && field.tagName === 'SELECT') {
            const textContent = mapping.targetText.toLowerCase();
            for (let i = 0; i < field.options.length; i++) {
                if (field.options[i].text.toLowerCase().includes(textContent)) {
                    field.selectedIndex = i;
                    this.triggerEvents(field);
                    this.highlightField(field);
                    return true;
                }
            }
        }

        return false;
    }

    transformDate(value, pattern) {
        if (!value) return value;
        let dateStr = String(value).trim();
        let day, month, year;

        const parts = dateStr.split(/[/\-.]/);
        if (parts.length === 3) {
            if (parts[2].length === 4) {
                [day, month, year] = parts;
            } else if (parts[0].length === 4) {
                [year, month, day] = parts;
            }
        }

        if (!day || !month || !year) return dateStr;

        day = day.padStart(2, '0');
        month = month.padStart(2, '0');

        switch (pattern) {
            case 'DD-MM-YYYY': return `${day}-${month}-${year}`;
            case 'DD/MM/YYYY': return `${day}/${month}/${year}`;
            case 'MM/DD/YYYY': return `${month}/${day}/${year}`;
            case 'YYYY-MM-DD': return `${year}-${month}-${day}`;
            default: return dateStr;
        }
    }

    // ==================== DATA PROCESSING ==================== //

    normalizeData(rawData) {
        const normalized = {};

        const processEntry = (key, value) => {
            let finalValue = value;

            if (value && typeof value === 'object' && 'value' in value) {
                finalValue = value.value;
            }

            if (finalValue === null || finalValue === undefined || String(finalValue).trim() === '') {
                return;
            }

            let cleanKey = key.toLowerCase();

            if (cleanKey.includes('aadhaar')) cleanKey = 'aadhaarnumber';
            if (cleanKey.includes('pan') && cleanKey.includes('number')) cleanKey = 'pannumber';
            if (cleanKey === 'fathersname') cleanKey = 'fathersname';
            if (cleanKey === 'mothersname') cleanKey = 'mothername';
            if (cleanKey === 'husbandsname') cleanKey = 'husbandname';

            if (typeof finalValue === 'string') {
                finalValue = finalValue.replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
            }

            normalized[cleanKey] = finalValue;
        };

        for (const [key, value] of Object.entries(rawData)) {
            processEntry(key, value);
        }

        return normalized;
    }

    shouldSkipField(input) {
        const skipTypes = ['disabled', 'hidden', 'submit', 'button', 'reset', 'file', 'image'];
        if (skipTypes.includes(input.type)) return true;
        if (input.disabled || input.readOnly) return true;
        if (input.style.display === 'none' || input.style.visibility === 'hidden') return true;
        return false;
    }

    // ==================== IDENTIFICATION SYSTEM ==================== //

    identifyField(field) {
        const dataKeys = Object.keys(this.extractedData || {});
        let bestKey = null;
        let bestScore = -1;

        for (const key of dataKeys) {
            const score = this.calculateMatchScore(field, key);
            if (score > bestScore) {
                bestScore = score;
                bestKey = key;
            }
        }

        return (bestScore >= 30) ? bestKey : null;
    }

    calculateMatchScore(field, dataKey) {
        let score = 0;
        const signals = this.getFieldSignals(field);
        const patterns = this.getPatterns(dataKey);

        if (!patterns || patterns.length === 0) return 0;

        if (signals.name === dataKey || signals.id === dataKey) return 100;

        if (signals.label === dataKey) return 90;
        if (signals.label && signals.label.includes(dataKey)) score = Math.max(score, 80);

        for (const pattern of patterns) {
            if (signals.name === pattern || signals.id === pattern) return 95;
            if (signals.label === pattern) return 90;

            const isShort = pattern.length <= 3;

            if (isShort) {
                const strictMatch = (text) => text === pattern || text.includes(`_${pattern}`) || text.includes(`${pattern}_`) || text.includes(`-${pattern}`) || text.includes(`${pattern}-`);

                if (strictMatch(signals.name)) score = Math.max(score, 85);
                if (strictMatch(signals.id)) score = Math.max(score, 85);
                if (signals.label === pattern) score = Math.max(score, 80);
            } else {
                if (signals.name && signals.name.includes(pattern)) score = Math.max(score, 80);
                if (signals.id && signals.id.includes(pattern)) score = Math.max(score, 80);
                if (signals.label && signals.label.includes(pattern)) score = Math.max(score, 75);
                if (signals.placeholder && signals.placeholder.includes(pattern)) score = Math.max(score, 60);
            }
        }

        return score;
    }


    getFieldSignals(field) {
        return {
            id: (field.id || '').toLowerCase(),
            name: (field.name || '').toLowerCase(),
            placeholder: (field.placeholder || '').toLowerCase(),
            label: this.getLabelText(field).toLowerCase(),
            type: (field.type || '').toLowerCase()
        };
    }

    getLabelText(field) {
        let labelText = '';

        if (field.id) {
            const label = document.querySelector(`label[for="${field.id}"]`);
            if (label) labelText += label.innerText;
        }

        const parentLabel = field.closest('label');
        if (parentLabel && parentLabel !== field) {
            labelText += parentLabel.innerText;
        }

        const aria = field.getAttribute('aria-label');
        if (aria) labelText += aria;

        const prev = field.previousElementSibling;
        if (prev && prev.tagName === 'LABEL') labelText += prev.innerText;

        return labelText.trim();
    }

    getPatterns(key) {
        const patterns = {
            aadhaarnumber: ['aadhaar', 'aadhar', 'uid', 'uidai', 'adhaar', 'aadhaar_number'],
            pannumber: ['pan', 'pancard', 'pan_card', 'permanent_account_number', 'pan_number'],
            voterid: ['voter', 'voterid', 'epic', 'election_card'],
            licensenumber: ['driving', 'license', 'dl_no', 'licence', 'dlno', 'licenseno'],
            passport: ['passport', 'passport_no'],

            fullname: ['fullname', 'full_name', 'username', 'candidate_name', 'applicant_name', 'txtappname', 'newFullName'],
            firstname: ['fname', 'firstname', 'first_name', 'first name', 'First name', 'given_name', 'Given name', 'given name', 'given name'],
            middlename: ['mname', 'middlename', 'middle_name', 'middle name', 'Middle name'],
            lastname: ['lname', 'lastname', 'last_name', 'last name', 'Last name'],
            fathersname: ['fname', 'father', 'father_name', 'guardian'],
            mothername: ['mother', 'mother_name'],
            husbandname: ['husband', 'spouse'],
            dob: ['dob', 'dateofbirth', 'date_of_birth', 'birth_date', 'birth'],
            gender: ['gender', 'sex', 'caste'],

            email: ['email', 'e-mail', 'mail_id'],
            mobile: ['mobile', 'phone', 'cell', 'contact', 'telephone', 'tel', 'mobile_no'],

            address: ['address', 'addr', 'residence', 'permanent_address'],
            city: ['city', 'town', 'district'],
            state: ['state', 'province', 'region'],
            pincode: ['pincode', 'pin', 'zip', 'zipcode', 'postal', 'postal_code', 'postal code', 'Postal code', 'Pin code'],
            country: ['country', 'nation'],
            rollnumber: ['sscrollno', 'rollnumber', 'roll_number', 'rollno', 'roll_no', 'rollno', 'roll_no', 'rollno', 'roll_no'],
            passingyear: ['txtmatriyearpassnew'],
            housenumber: ['presHouseNo', 'housenumber', 'house_number'],
            street: ['presStreet', 'street', 'street_address'],
            locality: ['presLocality', 'locality', 'locality_address'],
            landmark: ['presLandmark', 'presLocation', 'landmark', 'landmark_address'],
            taluka: ['presTaluka', 'taluka', 'taluka_address', 'presSubDistrict', 'presTehsil'],
            village: ['presCity', 'village', 'village_address'],
        };

        return patterns[key] || [];
    }

    // ==================== FILLING LOGIC (MODERN WEB) ====================

    fillField(input, value) {
        const fieldType = (input.type || input.tagName).toLowerCase();

        try {
            let filled = false;

            switch (fieldType) {
                case 'checkbox':
                    filled = this.fillCheckbox(input, value);
                    break;
                case 'radio':
                    filled = this.fillRadio(input, value);
                    break;
                case 'select-one':
                case 'select-multiple':
                    filled = this.fillSelect(input, value);
                    break;
                case 'date':
                    filled = this.fillDate(input, value);
                    break;
                case 'textarea':
                    filled = this.fillTextInput(input, value);
                    break;
                default:
                    filled = this.fillTextInput(input, value);
                    break;
            }

            if (filled) {
                this.highlightField(input);
                if (fieldType !== 'checkbox' && fieldType !== 'radio') {
                    this.addEditButton(input);
                }
                this.filledFields.set(input, true);
            }

            return filled;
        } catch (e) {
            console.error("Error filling field", input, e);
            return false;
        }
    }

    fillTextInput(input, value) {
        this.setNativeValue(input, value);
        return true;
    }

    setNativeValue(element, value) {
        const lastValue = element.value;
        element.value = value;
        const lastTracker = element._valueTracker;
        if (lastTracker) {
            lastTracker.setValue(lastValue);
        }
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        element.dispatchEvent(new Event('blur', { bubbles: true }));
    }

    fillCheckbox(input, value) {
        const strVal = String(value).toLowerCase();
        const isTrue = ['yes', 'true', '1', 'on', 'checked'].includes(strVal);
        const isFalse = ['no', 'false', '0', 'off', 'unchecked'].includes(strVal);

        if (isTrue) {
            input.checked = true;
            this.triggerEvents(input);
            return true;
        }
        if (isFalse) {
            input.checked = false;
            this.triggerEvents(input);
            return true;
        }
        return false;
    }

    fillRadio(input, value) {
        const dataVal = String(value).toLowerCase().trim();

        // CASE A: the Brain says "true/yes/1" — it already picked the SPECIFIC radio
        // via the selector (e.g. gender_female) and just wants THIS one checked.
        const isBoolTrue  = ['true', 'yes', '1', 'on', 'checked', 'selected'].includes(dataVal);
        const isBoolFalse = ['false', 'no', '0', 'off', 'unchecked'].includes(dataVal);
        if (isBoolTrue) {
            input.checked = true;
            this.triggerEvents(input);
            this.highlightField(input);
            return true;
        }
        if (isBoolFalse) {
            return true;
        }

        // CASE B: the value names WHICH option to pick (e.g. "Female").
        let group = [];
        if (input.name) {
            const safeName = (window.CSS && CSS.escape) ? CSS.escape(input.name) : input.name;
            group = Array.from(document.querySelectorAll(`input[type="radio"][name="${safeName}"]`));
        }
        if (group.length === 0) group = [input];

        const strictMatch = (radio) => {
            const fieldVal = String(radio.value || '').toLowerCase().trim();
            const labelText = this.getLabelText(radio).toLowerCase().trim();

            if (fieldVal === dataVal || labelText === dataVal) return true;

            if (labelText.startsWith(dataVal + ' ') || labelText.startsWith(dataVal + '/') || labelText.startsWith(dataVal + ' /')) return true;

            if (dataVal === 'male'   && (['m', 'male', 'man', 'mr'].includes(fieldVal)            || labelText.startsWith('male')))   return true;
            if (dataVal === 'female' && (['f', 'female', 'woman', 'ms', 'mrs'].includes(fieldVal) || labelText.startsWith('female'))) return true;

            return false;
        };

        const target = group.find(strictMatch);
        if (target) {
            target.checked = true;
            this.triggerEvents(target);
            this.highlightField(target);
            return true;
        }

        return false;
    }

    fillSelect(select, value) {
        const dataVal = String(value).toLowerCase();

        for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].value.toLowerCase() === dataVal) {
                select.selectedIndex = i;
                this.triggerEvents(select);
                return true;
            }
        }

        for (let i = 0; i < select.options.length; i++) {
            if (select.options[i].text.toLowerCase().includes(dataVal)) {
                select.selectedIndex = i;
                this.triggerEvents(select);
                return true;
            }
        }

        return false;
    }

    fillDate(input, value) {
        let dateStr = String(value).trim();

        if (dateStr.includes('/')) {
            const parts = dateStr.split('/');
            if (parts.length === 3) {
                const [d, m, y] = parts;
                dateStr = `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
            }
        }

        input.value = dateStr;
        this.triggerEvents(input);
        return true;
    }

    // ==================== UTILS ====================

    triggerEvents(element) {
        ['input', 'change', 'blur', 'focus'].forEach(evt => {
            element.dispatchEvent(new Event(evt, { bubbles: true }));
        });
    }

    highlightField(input) {
        const originalBorder = input.style.border;
        const originalBg = input.style.backgroundColor;

        input.style.border = '2px solid #10b981';
        input.style.backgroundColor = '#ecfdf5';

        setTimeout(() => {
            input.style.border = originalBorder;
            input.style.backgroundColor = originalBg;
        }, 2000);
    }

    addEditButton(input) {
        return;
    }

    showNotification(msg, type = 'success') {
        const div = document.createElement('div');
        div.textContent = msg;
        div.style.cssText = `
            position: fixed; top: 20px; right: 20px; padding: 15px 25px;
            background: ${type === 'success' ? '#10b981' : '#f59e0b'};
            color: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 999999; font-family: sans-serif; font-weight: bold;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(div);
        setTimeout(() => div.remove(), 3000);
    }

    injectStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn { from { transform: translateX(-100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
            
            #dc-floating-widget {
                position: fixed;
                bottom: 20px;
                left: 20px;
                width: 230px;
                background: white;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                border-radius: 10px;
                font-family: 'Segoe UI', sans-serif;
                z-index: 2147483647;
                overflow: hidden;
                border: 1px solid #e1e4e8;
                animation: slideIn 0.3s ease;
            }
            .dc-widget-header {
                background: linear-gradient(135deg, #2563eb, #1e40af);
                color: white;
                padding: 9px 12px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .dc-logo { font-weight: 600; font-size: 12px; }
            .dc-header-controls { display: flex; gap: 8px; }
            #dc-close-widget, #dc-toggle-widget {
                background: none; border: none; color: white;
                font-size: 18px; cursor: pointer; padding: 0;
            }
            #dc-toggle-widget { font-size: 14px; }
            
            .dc-widget-content { padding: 12px; }
            .dc-widget-content p {
                margin: 0 0 10px 0; color: #4b5563; font-size: 12px;
            }
            .dc-widget-actions { display: flex; gap: 8px; }
            .dc-btn-primary {
                flex: 1;
                background: #10b981;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 6px;
                font-weight: 600;
                cursor: pointer;
                transition: background 0.2s;
            }
            .dc-btn-primary:hover { background: #059669; }
            .dc-btn-secondary {
                background: #f3f4f6;
                color: #6b7280;
                border: 1px solid #d1d5db;
                padding: 8px 12px;
                border-radius: 6px;
                cursor: pointer;
                transition: background 0.2s;
            }
            .dc-btn-secondary:hover { background: #e5e7eb; }
        `;
        document.head.appendChild(style);
    }
}

new FormFillerContent();