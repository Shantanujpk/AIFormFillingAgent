// DigitalClerk Background Service Worker with Authentication
//
// ===================================================================
// ALPHA — pocket enabled (multi-page persistence)  +  GROQ mapping
// -------------------------------------------------------------------
// PRODUCTION BUILD: the mapping ("Brain") call points at the GROQ /fill
// endpoint on Railway (public, no auth). This is the switch BACK from the
// local Gemini testing build.
//
// To switch to local Gemini for testing again: point PILOT_URL at
// `${API_URL}/form-pilot/fill` and add the Authorization header back in
// handleApiFillForm. content.js / scanner.js are model-agnostic — they
// never change when the mapping brain changes.
//
// Pocket = a per-TAB session store (chrome.storage.session, memory only)
// that holds the user's extracted data so pages 2..N auto-fill with NO
// re-upload. Keyed by tabId (stable across reloads + SPA nav).
// ===================================================================

class BackgroundService {
    constructor() {
        //this.API_URL = 'http://localhost:4000/api/v1'; // Local backend URL
        this.API_URL = 'https://digital-clerk-b2c-backend-backup.onrender.com/api/v1/';

        // GROQ mapping ("Brain") endpoint on Railway. Public (no auth check).
        this.PILOT_URL = 'https://formpilot-api-zjaq.onrender.com/fill';

        // Prefix for pocket keys in chrome.storage.session -> "dc_pocket_<tabId>"
        this.POCKET_PREFIX = 'dc_pocket_';

        this.extractedData = {};
        this.setupListeners();
        console.log('DigitalClerk Background Service Loaded ✓ (Alpha pocket + GROQ mapping)');
    }

    setupListeners() {
        // Listen for messages from popup / content script
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'extractDocument') {
                this.extractDocument(request.document)
                    .then(data => sendResponse({ success: true, data }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true;
            }

            if (request.action === 'getExtractedData') {
                sendResponse({ data: this.extractedData });
            }

            if (request.action === 'checkAuth') {
                this.checkAuthStatus()
                    .then(result => sendResponse(result))
                    .catch(error => sendResponse({ authenticated: false }));
                return true;
            }

            if (request.action === 'apiFillForm') {
                this.handleApiFillForm(request.fields, request.userData)
                    .then(instructions => sendResponse({ success: true, instructions }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true;
            }

            // ===== ALPHA: pocket message API =====

            // popup.js -> save extracted data into this tab's pocket.
            if (request.action === 'savePocket') {
                this.savePocket(request)
                    .then(pocket => sendResponse({ success: true, pocket }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true;
            }

            // content.js -> read this tab's pocket (worker reads tab id from sender).
            if (request.action === 'getPocket') {
                const tabId = (sender && sender.tab && sender.tab.id != null)
                    ? sender.tab.id
                    : request.tabId;
                this.getPocket(tabId)
                    .then(pocket => sendResponse({ success: true, pocket }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true;
            }

            // content.js / stop logic -> clear this tab's pocket.
            if (request.action === 'clearPocket') {
                const tabId = (sender && sender.tab && sender.tab.id != null)
                    ? sender.tab.id
                    : request.tabId;
                this.clearPocket(tabId)
                    .then(() => sendResponse({ success: true }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true;
            }
        });

        // Listen for external messages from web app
        chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
            if (request.action === 'syncProfile') {
                this.handleProfileSync(request.data);
                sendResponse({ success: true });
            }
        });

        // Check auth on extension install/update
        chrome.runtime.onInstalled.addListener(() => {
            this.checkAuthStatus();
        });

        // When a tab closes, drop its pocket so PII doesn't linger in memory.
        if (chrome.tabs && chrome.tabs.onRemoved) {
            chrome.tabs.onRemoved.addListener((tabId) => {
                this.clearPocket(tabId).catch(() => {});
            });
        }
    }

    // ==================== ALPHA: POCKET METHODS ====================

    _pocketKey(tabId) {
        return `${this.POCKET_PREFIX}${tabId}`;
    }

    async savePocket({ tabId, formId, extractedFields, formInstructions }) {
        if (tabId == null) {
            throw new Error('savePocket: tabId is required');
        }

        let origin = null;
        try {
            const tab = await chrome.tabs.get(tabId);
            if (tab && tab.url) origin = new URL(tab.url).origin;
        } catch (e) {
            // tab may be gone; origin stays null, not fatal
        }

        const pocket = {
            tabId,
            formId: formId || null,
            origin,
            createdAt: Date.now(),
            updatedAt: Date.now(),

            extractedFields: extractedFields || {},   // RAW, whole, as returned by extraction
            formInstructions: formInstructions || null,

            // reserved for later stop-logic step (declared now to avoid reshaping)
            filledSignatures: [],
            idlePageCount: 0,
            state: 'ACTIVE'
        };

        await chrome.storage.session.set({ [this._pocketKey(tabId)]: pocket });
        console.log(`[POCKET] saved for tab ${tabId}`, {
            formId: pocket.formId,
            origin: pocket.origin,
            fieldCount: Object.keys(pocket.extractedFields).length
        });
        return pocket;
    }

    async getPocket(tabId) {
        if (tabId == null) return null;
        const key = this._pocketKey(tabId);
        const result = await chrome.storage.session.get([key]);
        const pocket = result[key] || null;
        console.log(`[POCKET] read for tab ${tabId}:`, pocket ? 'found' : 'none');
        return pocket;
    }

    async clearPocket(tabId) {
        if (tabId == null) return;
        await chrome.storage.session.remove([this._pocketKey(tabId)]);
        console.log(`[POCKET] cleared for tab ${tabId}`);
    }

    // ==================== (auth / extraction / sync — unchanged) ====================

    async checkAuthStatus() {
        try {
            const result = await chrome.storage.local.get(['authToken', 'user']);

            if (result.authToken && result.user) {
                const response = await fetch(`${this.API_URL}/auth/verify`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${result.authToken}`
                    }
                });

                const data = await response.json();

                if (data.success) {
                    await chrome.storage.local.set({ user: data.user });
                    return { authenticated: true, user: data.user };
                } else {
                    await chrome.storage.local.remove(['authToken', 'user']);
                    return { authenticated: false };
                }
            }

            return { authenticated: false };
        } catch (error) {
            console.error('Auth check error:', error);
            return { authenticated: false };
        }
    }

    async extractDocument(document) {
        console.log('Extracting data from document:', document.name);

        try {
            const { authToken } = await chrome.storage.local.get(['authToken']);

            if (!authToken) {
                throw new Error('Not authenticated');
            }

            const response = await fetch(`${this.API_URL}/extract/single`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${authToken}`
                },
                body: JSON.stringify({
                    document: {
                        name: document.name,
                        type: document.type,
                        content: document.content
                    }
                })
            });

            const result = await response.json();

            if (result.success) {
                this.extractedData[document.id] = result.data;
                await chrome.storage.local.set({
                    [`extracted_${document.id}`]: result.data
                });
                return result.data;
            } else {
                throw new Error(result.message);
            }
        } catch (error) {
            console.error('Extraction error:', error);
            throw error;
        }
    }

    async handleProfileSync(profileData) {
        console.log('Syncing profile from web app:', profileData);

        try {
            const { user } = await chrome.storage.local.get(['user']);
            const updatedUser = { ...user, ...profileData };
            await chrome.storage.local.set({ user: updatedUser });
            chrome.runtime.sendMessage({ action: 'profileUpdated', data: updatedUser });
        } catch (error) {
            console.error('Profile sync error:', error);
        }
    }

    // ==================== MAPPING (GROQ production build) ====================

    async handleApiFillForm(fields, userData) {
        try {
            // GROQ Railway endpoint is PUBLIC — no Authorization header.
            // (The Gemini build sent a Bearer token; Groq does not need one.)

            // Reshape each scanned field into the schema the mapping service expects.
            // Scanner gives options as [{value, text}] and the element as "tagName";
            // the server wants options as plain strings and the key "tag". We forward
            // the richer context (placeholder/pattern/maxLength/ariaLabel/previousHeading)
            // so the date-format and dropdown rules can use it.
            const normalizedFields = fields.map(f => ({
                id:              f.id,
                label:           f.label || f.ariaLabel || f.placeholder || '',
                placeholder:     f.placeholder || '',
                type:            f.type,
                tag:             (f.tagName || 'input').toUpperCase(),
                options: Array.isArray(f.options)
                    ? f.options.map(o => (o.text || o.value || '').trim()).filter(Boolean)
                    : [],
                maxLength:       f.maxLength ?? null,
                pattern:         f.pattern ?? null,
                ariaLabel:       f.ariaLabel || '',
                previousHeading: f.previousHeading || '',
                signature:       f.signature
            }));

            // ---- GROQ mapping endpoint (public) ----
            const response = await fetch(this.PILOT_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                    // No Authorization header: Railway/Groq endpoint is public.
                },
                body: JSON.stringify({
                    session_id: Date.now().toString(),
                    fields: normalizedFields,
                    user_data: userData
                    // entry_num: <n>   // add later if/when multi-entry forms are handled
                })
            });

            if (!response.ok) {
                const errText = await response.text().catch(() => '');
                throw new Error(`Mapping service error ${response.status}: ${errText}`);
            }

            const pilotData = await response.json();

            const formFillInstructions = (pilotData.mapping || []).map(m => {
                let selector = m.id;
                if (!selector.startsWith('#') && !selector.startsWith('.') && !selector.startsWith('[')) {
                    const safe = (typeof CSS !== 'undefined' && CSS.escape) ? CSS.escape(m.id) : m.id;
                    selector = `[id="${safe}"], [name="${safe}"], [data-dc-id="${safe}"]`;
                }
                return {
                    fieldId: selector,
                    value: m.value,
                    action: m.action
                };
            });

            return formFillInstructions;
        } catch (error) {
            console.error('API Fill Form error:', error);
            throw error;
        }
    }
}

// Initialize
new BackgroundService();